const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const fs = require('fs');

if (!fs.existsSync('./transcripts')) fs.mkdirSync('./transcripts');
if (!fs.existsSync('./logs')) fs.mkdirSync('./logs');

const dbPath = path.resolve(__dirname, 'tickets.db');
const db = new sqlite3.Database(dbPath);

db.serialize(() => {
  // ==================== TABLA PRINCIPAL DE TICKETS ====================
  db.run(`
    CREATE TABLE IF NOT EXISTS tickets (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      ticketId TEXT UNIQUE NOT NULL,
      userId TEXT NOT NULL,
      channelId TEXT UNIQUE NOT NULL,
      category TEXT NOT NULL,
      answers TEXT,
      status TEXT DEFAULT 'open',
      createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
      closedAt DATETIME,
      claimedBy TEXT,
      priority TEXT DEFAULT 'normal',
      reminderCount INTEGER DEFAULT 0,
      userReminderCount INTEGER DEFAULT 0,
      transcript TEXT,
      closedBy TEXT,
      closeReason TEXT,
      rating INTEGER DEFAULT NULL,
      pendingClose DATETIME DEFAULT NULL,
      transferTo TEXT
    )
  `);

  // ==================== VERIFICAR Y AÑADIR COLUMNAS FALTANTES ====================
  db.all("PRAGMA table_info(tickets)", (err, rows) => {
    if (!err && rows) {
      const cols = rows.map(r => r.name);
      const columnsToAdd = [
        { name: 'answers', type: 'TEXT' },
        { name: 'closedBy', type: 'TEXT' },
        { name: 'closeReason', type: 'TEXT' },
        { name: 'transcript', type: 'TEXT' },
        { name: 'userReminderCount', type: 'INTEGER DEFAULT 0' },
        { name: 'rating', type: 'INTEGER DEFAULT NULL' },
        { name: 'pendingClose', type: 'DATETIME DEFAULT NULL' },
        { name: 'transferTo', type: 'TEXT' }
      ];
      
      for (const col of columnsToAdd) {
        if (!cols.includes(col.name)) {
          db.run(`ALTER TABLE tickets ADD COLUMN ${col.name} ${col.type}`, (err) => {
            if (err) console.error(`Error añadiendo columna ${col.name}:`, err.message);
            else console.log(`✅ Columna ${col.name} añadida correctamente`);
          });
        }
      }
    }
  });

  // ==================== TABLA DE LOGS ====================
  db.run(`
    CREATE TABLE IF NOT EXISTS logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      ticketId TEXT NOT NULL,
      action TEXT NOT NULL,
      userId TEXT NOT NULL,
      details TEXT,
      timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // ==================== TABLA DE USUARIOS ====================
  db.run(`
    CREATE TABLE IF NOT EXISTS users (
      userId TEXT PRIMARY KEY,
      ticketsOpened INTEGER DEFAULT 0,
      ticketsClosed INTEGER DEFAULT 0,
      lastTicket DATETIME,
      totalMessages INTEGER DEFAULT 0
    )
  `);

  // ==================== TABLA DE ESTADÍSTICAS DE STAFF ====================
  db.run(`
    CREATE TABLE IF NOT EXISTS staff_stats (
      userId TEXT PRIMARY KEY,
      ticketsClaimed INTEGER DEFAULT 0,
      ticketsClosed INTEGER DEFAULT 0,
      avgResponseTime INTEGER DEFAULT 0,
      totalTime INTEGER DEFAULT 0
    )
  `);

  // ==================== TABLA PARA ROLES GUARDADOS ====================
  db.run(`
    CREATE TABLE IF NOT EXISTS saved_admin_roles (
      userId TEXT PRIMARY KEY,
      guildId TEXT NOT NULL,
      roles TEXT NOT NULL,
      timeoutEndsAt DATETIME NOT NULL
    )
  `);

  // ==================== ÍNDICES PARA RENDIMIENTO ====================
  db.run('CREATE INDEX IF NOT EXISTS idx_tickets_userId ON tickets(userId)');
  db.run('CREATE INDEX IF NOT EXISTS idx_tickets_status ON tickets(status)');
  db.run('CREATE INDEX IF NOT EXISTS idx_tickets_category ON tickets(category)');
  db.run('CREATE INDEX IF NOT EXISTS idx_tickets_channelId ON tickets(channelId)');
  db.run('CREATE INDEX IF NOT EXISTS idx_tickets_pendingClose ON tickets(pendingClose)');
  db.run('CREATE INDEX IF NOT EXISTS idx_logs_ticketId ON logs(ticketId)');

  console.log('✅ Base de datos inicializada y verificada correctamente');
});

// ==================== FUNCIONES CON PROMESAS ====================
function run(sql, params) {
  return new Promise((resolve, reject) => {
    db.run(sql, params, function(err) {
      if (err) reject(err);
      else resolve(this);
    });
  });
}

function get(sql, params) {
  return new Promise((resolve, reject) => {
    db.get(sql, params, (err, row) => {
      if (err) reject(err);
      else resolve(row);
    });
  });
}

function all(sql, params) {
  return new Promise((resolve, reject) => {
    db.all(sql, params, (err, rows) => {
      if (err) reject(err);
      else resolve(rows);
    });
  });
}

module.exports = {
  db,
  run,
  get,
  all
};