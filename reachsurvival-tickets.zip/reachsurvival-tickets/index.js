const fs = require('fs');
const path = require('path');
const {
  Client,
  GatewayIntentBits,
  Partials,
  REST,
  Routes,
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  PermissionsBitField,
  ChannelType,
  AttachmentBuilder,
  PermissionFlagsBits
} = require('discord.js');

const config = require('./config.json');
const db = require('./database.js');

// ==================== VALIDACIÓN DE CONFIG ====================
const REQUIRED_KEYS = ['token', 'clientId', 'guildId'];
for (const key of REQUIRED_KEYS) {
  if (!config[key] || String(config[key]).startsWith('PON_AQUI')) {
    console.error(`❌ Falta configurar "${key}" en config.json.`);
    process.exit(1);
  }
}

// ==================== CATEGORÍAS Y PREGUNTAS ====================
const CATEGORIES = {
  apelacion: {
    roles: [],
    description: 'Apelación',
    emoji: '📝',
    menuDescription: 'Apela una sanción o baneo',
    categoryId: '1519251872571985951'
  },
  donacion: {
    roles: [],
    description: 'Donación',
    emoji: '💎',
    menuDescription: 'Donaciones, rangos VIP o items',
    categoryId: '1551350473897017435'
  },
  streamer: {
    roles: [],
    description: 'Streamer',
    emoji: '🎥',
    menuDescription: 'Solicita el rol de streamer del servidor',
    categoryId: '1551350830999797890'
  },
  reporte_staff: {
    roles: [],
    description: 'Reporte STAFF',
    emoji: '🚨',
    menuDescription: 'Reporta abuso de poder o mal comportamiento de staff',
    categoryId: '1551305527122853898'
  },
  postulacion_staff: {
    roles: [],
    description: 'Postulación STAFF',
    emoji: '👑',
    menuDescription: 'Postúlate para unirte al equipo de staff',
    categoryId: '1551351079332094094'
  },
  reporte: {
    roles: [],
    description: 'Reporte Jugador',
    emoji: '🚩',
    menuDescription: 'Reporta a un jugador por romper las normas',
    categoryId: '1551305667258876014'
  },
  soporte: {
    roles: [],
    description: 'Soporte',
    emoji: '🛠️',
    menuDescription: 'Ayuda técnica, dudas o problemas en el servidor',
    categoryId: '1551297292068327564'
  },
  otros: {
    roles: [],
    description: 'Otros',
    emoji: '📦',
    menuDescription: 'Cualquier otra consulta que no encaje arriba',
    categoryId: '1510223819871354910'
  }
};

const DEFAULT_CATEGORY_ID = '1510223819871354910';
const DEFAULT_QUESTIONS = [{ id: 'q1', label: 'Describe tu consulta con el mayor detalle posible', style: TextInputStyle.Paragraph }];

const QUESTIONS = {
  apelacion: [
    { id: 'q1', label: '¿Cuál es tu nombre de usuario dentro del servidor?', style: TextInputStyle.Short },
    { id: 'q2', label: '¿Por qué fuiste sancionado/a?', style: TextInputStyle.Paragraph },
    { id: 'q3', label: '¿Por qué deberíamos levantar tu sanción?', style: TextInputStyle.Paragraph }
  ],
  donacion: [
    { id: 'q1', label: '¿Qué producto o paquete deseas donar/comprar?', style: TextInputStyle.Short },
    { id: 'q2', label: '¿Tienes comprobante o ID de la transacción?', style: TextInputStyle.Paragraph }
  ],
  streamer: [
    { id: 'q1', label: 'Enlace a tu canal de streaming', style: TextInputStyle.Short },
    { id: 'q2', label: '¿Cuántos seguidores o suscriptores tienes?', style: TextInputStyle.Short },
    { id: 'q3', label: '¿Por qué quieres el rol de streamer del servidor?', style: TextInputStyle.Paragraph }
  ],
  reporte_staff: [
    { id: 'q1', label: 'Staff reportado (nombre y/o ID)', style: TextInputStyle.Short },
    { id: 'q2', label: 'Motivo del reporte hacia el staff', style: TextInputStyle.Short },
    { id: 'q3', label: 'Describe detalladamente lo sucedido', style: TextInputStyle.Paragraph },
    { id: 'q4', label: '¿Tienes evidencia audiovisual? (Enlace)', style: TextInputStyle.Paragraph }
  ],
  postulacion_staff: [
    { id: 'q1', label: '¿Qué cargo de staff te gustaría ocupar?', style: TextInputStyle.Short },
    { id: 'q2', label: '¿Cuántos años tienes y cuánto tiempo disponible tienes al día?', style: TextInputStyle.Short },
    { id: 'q3', label: '¿Por qué quieres ser parte del equipo de staff?', style: TextInputStyle.Paragraph },
    { id: 'q4', label: '¿Tienes experiencia previa como staff? Cuéntanos', style: TextInputStyle.Paragraph }
  ],
  reporte: [
    { id: 'q1', label: 'Nombre y ID del jugador reportado', style: TextInputStyle.Short },
    { id: 'q2', label: 'Motivo del reporte', style: TextInputStyle.Short },
    { id: 'q3', label: 'Describe detalladamente lo sucedido', style: TextInputStyle.Paragraph },
    { id: 'q4', label: '¿Tienes evidencia? (clip o capturas)', style: TextInputStyle.Paragraph }
  ],
  soporte: [
    { id: 'q1', label: 'Describe tu problema o consulta con detalle', style: TextInputStyle.Paragraph },
    { id: 'q2', label: '¿Qué has intentado para resolverlo?', style: TextInputStyle.Paragraph }
  ],
  otros: [
    { id: 'q1', label: 'Describe tu consulta con el mayor detalle posible', style: TextInputStyle.Paragraph }
  ]
};

function questionsFor(categoryKey) {
  return QUESTIONS[categoryKey] || DEFAULT_QUESTIONS;
}

// ==================== ROLES ====================
const STAFF_ROLE_IDS = Array.isArray(config.staffRoles) ? config.staffRoles : [];
const USER_CLOSE_ROLE_ID = '1509658651235844156';
const NORMAL_USER_ROLE_ID = '1529691931557494813';
const TICKET_ROLE_ID = '1546389501847535717';

function isStaff(member) {
  if (!member) return false;
  if (config.owners && config.owners.includes(member.id)) return true;
  if (member.permissions?.has(PermissionsBitField.Flags.Administrator)) return true;
  return STAFF_ROLE_IDS.some((id) => member.roles.cache.has(id));
}

function isAdmin(member) {
  if (!member) return false;
  if (config.owners && config.owners.includes(member.id)) return true;
  return member.permissions?.has(PermissionsBitField.Flags.Administrator) || false;
}

// ==================== CLIENTE DE DISCORD ====================
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.DirectMessages
  ],
  partials: [Partials.Channel]
});

// ==================== ALMACENAMIENTO DE ADVERTENCIAS ====================
const warnings = new Map();

// ==================== UTILIDADES ====================

function makeTicketId() {
  const suffix = Math.random().toString(16).slice(2, 8).toUpperCase();
  return 'EX-' + Date.now().toString(36).toUpperCase() + '-' + suffix;
}

function channelNameFor(user) {
  const raw = (user.username || user.id || 'usuario')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9-]/g, '')
    .slice(0, 30);
  return ('ticket-' + (raw || String(user.id).slice(-6))).slice(0, 90);
}

async function addLog(ticketId, action, userId, details) {
  try {
    await db.run('INSERT INTO logs (ticketId, action, userId, details) VALUES (?, ?, ?, ?)', [ticketId, action, userId, details || '']);
  } catch (err) {
    console.error('Error guardando log:', err.message);
  }
}

async function requireTicket(channelId) {
  const ticket = await db.get('SELECT * FROM tickets WHERE channelId = ? LIMIT 1', [channelId]);
  if (!ticket) throw new Error('No encontré este ticket en la base de datos.');
  return ticket;
}

async function getOpenTicketsCount(userId) {
  const result = await db.get('SELECT COUNT(*) as count FROM tickets WHERE userId = ? AND status = "open"', [userId]);
  return result?.count || 0;
}

async function getActualOpenTickets(userId, guild) {
  const tickets = await db.all('SELECT * FROM tickets WHERE userId = ? AND status = "open"', [userId]);
  let validTickets = 0;
  for (const ticket of tickets) {
    try {
      const channel = await guild.channels.fetch(ticket.channelId);
      if (channel) validTickets++;
      else {
        await db.run('UPDATE tickets SET status = "closed", closedAt = CURRENT_TIMESTAMP WHERE channelId = ?', [ticket.channelId]);
        console.log(`🔒 Canal ${ticket.channelId} eliminado, ticket cerrado automáticamente`);
      }
    } catch (e) {
      await db.run('UPDATE tickets SET status = "closed", closedAt = CURRENT_TIMESTAMP WHERE channelId = ?', [ticket.channelId]);
      console.log(`🔒 Canal ${ticket.channelId} no encontrado, ticket cerrado automáticamente`);
    }
  }
  const result = await db.get('SELECT COUNT(*) as count FROM tickets WHERE userId = ? AND status = "open"', [userId]);
  return result?.count || 0;
}

function trimText(value, max) {
  const text = String(value || '');
  return text.length > max ? text.slice(0, Math.max(0, max - 15)) + '\n...[recortado]' : text;
}

function escapeHTML(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/\n/g, '<br>');
}

async function getTicketIdByChannel(interaction, channelId) {
  try { const ticket = await requireTicket(channelId); return ticket.ticketId || 'unknown'; } catch { return 'unknown'; }
}

// ==================== SISTEMA ANTI-MENCIONES A STAFF ====================
async function checkStaffMentions(message) {
  if (!message.channel.name?.startsWith('ticket-')) return;
  if (message.author.bot) return;
  if (isStaff(message.member)) return;
  
  const staffRoleIds = [...STAFF_ROLE_IDS, TICKET_ROLE_ID];
  const mentionedRoles = message.mentions.roles;
  
  let hasStaffMention = false;
  let mentionedStaffRoles = [];
  
  for (const roleId of staffRoleIds) {
    if (mentionedRoles.has(roleId)) {
      hasStaffMention = true;
      mentionedStaffRoles.push(`<@&${roleId}>`);
    }
  }
  
  if (hasStaffMention) {
    try {
      await message.delete();
      
      const warningEmbed = new EmbedBuilder()
        .setColor(0xe74c3c)
        .setTitle('🚫 No puedes etiquetar al staff')
        .setDescription(`**${message.author.username}**, no está permitido etiquetar a los equipos de staff.`)
        .addFields(
          { name: '📌 ¿Qué hacer?', value: 'Si necesitas atención, usa el botón **"⏰ Pedir atención"** en el ticket.', inline: false },
          { name: '🔔 Etiquetas eliminadas', value: mentionedStaffRoles.join(', '), inline: true }
        )
        .setFooter({ text: '𝐑𝐄𝐀𝐂𝐇𝐒𝐔𝐑𝐕𝐈𝐕𝐀𝐋 𝐓𝐈𝐂𝐊𝐄𝐓𝐒 — Sistema de Tickets' })
        .setTimestamp();
      
      await message.channel.send({ 
        embeds: [warningEmbed],
        allowed_mentions: { parse: [] }
      });
      
      console.log(`🚫 Usuario ${message.author.username} intentó etiquetar staff en ${message.channel.name}`);
    } catch (error) {
      console.error('Error eliminando mensaje con mención a staff:', error.message);
    }
  }
}

// ==================== SISTEMA DE ADVERTENCIAS ====================
async function checkAndWarnStaff(interaction) {
  const channel = interaction.channel;
  if (!channel || !channel.name?.startsWith('ticket-')) return;

  const ticket = await db.get('SELECT * FROM tickets WHERE channelId = ? LIMIT 1', [channel.id]);
  if (!ticket) return;

  const member = interaction.member;
  if (!isStaff(member)) return;

  if (ticket.userId === member.id) return;
  if (ticket.claimedBy === member.id) return;

  const key = `${member.id}_${channel.id}`;
  const warningData = warnings.get(key) || { count: 0, timestamp: Date.now() };

  if (Date.now() - warningData.timestamp > 3600000) {
    warningData.count = 0;
  }

  warningData.count++;
  warningData.timestamp = Date.now();
  warnings.set(key, warningData);

  const warningCount = warningData.count;
  const claimedBy = ticket.claimedBy ? `<@${ticket.claimedBy}>` : 'nadie (ticket sin reclamar)';

  let embed = null;

  const colors = { 1: 0xF1C40F, 2: 0xE67E22, 3: 0xE74C3C };
  const titles = {
    1: '⚠️ Primera Advertencia',
    2: '⚠️⚠️ Segunda Advertencia',
    3: '⛔ Tercera Advertencia - ¡Timeout!'
  };
  const descriptions = {
    1: `**${member.user.username}**, estás hablando en un ticket que no has reclamado.`,
    2: `**${member.user.username}**, esta es tu **SEGUNDA** advertencia. ¡Reclama el ticket ahora!`,
    3: `**${member.user.username}** has recibido **3 advertencias** por no reclamar el ticket.`
  };

  if (warningCount === 1 || warningCount === 2) {
    embed = new EmbedBuilder()
      .setColor(colors[warningCount])
      .setTitle(titles[warningCount])
      .setDescription(descriptions[warningCount])
      .addFields(
        { name: '📋 Ticket', value: `<#${channel.id}>`, inline: true },
        { name: '👤 Reclamado por', value: claimedBy, inline: true },
        { name: '📊 Advertencia', value: `${warningCount}/3`, inline: true },
        { name: '📌 ¿Qué debes hacer?', value: 'Presiona el botón **"Reclamar"** para poder hablar sin restricciones.', inline: false },
        { name: '⚠️ Consecuencias', value: warningCount === 1 
          ? '• 3 advertencias = **5 minutos de timeout**\n• Reincidencia = **15 minutos de timeout**' 
          : '⚠️ **¡ÚLTIMA OPORTUNIDAD!** La próxima advertencia será **5 minutos de timeout**.', inline: false }
      )
      .setFooter({ text: `𝐑𝐄𝐀𝐂𝐇𝐒𝐔𝐑𝐕𝐈𝐕𝐀𝐋 𝐓𝐈𝐂𝐊𝐄𝐓𝐒 — Sistema de Advertencias | Staff: ${member.user.username}` })
      .setTimestamp();
  } else if (warningCount >= 3) {
    const timeoutDuration = 5 * 60 * 1000;

    embed = new EmbedBuilder()
      .setColor(0xE74C3C)
      .setTitle('⛔ Tercera Advertencia - Timeout Aplicado')
      .setDescription(`**${member.user.username}** ha recibido **3 advertencias** por hablar sin reclamar el ticket.`)
      .addFields(
        { name: '📋 Ticket', value: `<#${channel.id}>`, inline: true },
        { name: '⏱️ Duración del timeout', value: '**5 minutos**', inline: true },
        { name: '📊 Advertencias', value: `3/3`, inline: true },
        { name: '📌 ¿Qué debes hacer?', value: 'Espera los **5 minutos** y luego reclama el ticket.', inline: false },
        { name: '⚠️ Próxima infracción', value: 'Si vuelves a hablar sin reclamar después del timeout, recibirás **15 minutos** de timeout.', inline: false }
      )
      .setFooter({ text: `𝐑𝐄𝐀𝐂𝐇𝐒𝐔𝐑𝐕𝐈𝐕𝐀𝐋 𝐓𝐈𝐂𝐊𝐄𝐓𝐒 — Sistema de Advertencias | Staff: ${member.user.username}` })
      .setTimestamp();

    try {
      await member.timeout(timeoutDuration, 'Hablar sin reclamar el ticket (3 advertencias)');
      await channel.send({ content: `⏳ **<@${member.id}> ha recibido un timeout de 5 minutos** por acumular 3 advertencias.` });
    } catch (error) {
      console.error('❌ Error aplicando timeout:', error.message);
      await channel.send({ content: `⚠️ **Error al aplicar timeout a <@${member.id}>.** Verifica que el bot tenga el permiso **"Moderate Members"**.` });
    }
    warnings.delete(key);
  }

  if (embed) {
    await channel.send({ embeds: [embed] });
  }
}

// ==================== TRANSCRIPCIÓN ====================
async function discordRequest(endpoint, method, body, token) {
  const url = `https://discord.com/api/v10/${endpoint}`;
  const options = { 
    method: method || 'GET',
    headers: { 
      'Authorization': `Bot ${token}`, 
      'Content-Type': 'application/json' 
    } 
  };
  if (body) options.body = JSON.stringify(body);
  const response = await fetch(url, options);
  if (!response.ok) {
    const data = await response.json().catch(() => ({}));
    throw new Error(`Discord API ${response.status}: ${data.message || response.statusText}`);
  }
  return response.json();
}

async function getFullChannelMessages(channelId, token) {
  let messages = [], lastId = null, hasMore = true;
  while (hasMore) {
    try {
      const endpoint = `channels/${channelId}/messages?limit=100${lastId ? `&before=${lastId}` : ''}`;
      const batch = await discordRequest(endpoint, 'GET', null, token);
      if (batch.length === 0) { hasMore = false; }
      else {
        messages = messages.concat(batch);
        lastId = batch[batch.length - 1].id;
        if (batch.length < 100) hasMore = false;
      }
    } catch (error) {
      console.error('Error obteniendo mensajes:', error.message);
      hasMore = false;
    }
  }
  return messages;
}

function buildTranscriptHTML(ticketId, channelId, channelName, messages, guild) {
  const avatarURL = guild?.iconURL({ dynamic: true, size: 64 }) || 'https://cdn.discordapp.com/embed/avatars/0.png';
  const guildName = guild?.name || '𝐑𝐄𝐀𝐂𝐇𝐒𝐔𝐑𝐕𝐈𝐕𝐀𝐋 𝐓𝐈𝐂𝐊𝐄𝐓𝐒';
  
  const styles = `
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      background: #1a0a0a;
      font-family: 'Segoe UI', 'Helvetica Neue', Arial, sans-serif;
      display: flex;
      justify-content: center;
      padding: 20px;
      min-height: 100vh;
      color: #ff4d4d;
    }
    .container {
      max-width: 1000px;
      width: 100%;
      background: #1a0a0a;
      border: 1px solid #3d1a1a;
      border-radius: 16px;
      overflow: hidden;
      box-shadow: 0 20px 60px rgba(0,0,0,0.8);
    }
    .header {
      background: linear-gradient(135deg, #1a0505 0%, #2a0a0a 50%, #1a0505 100%);
      padding: 24px 30px;
      border-bottom: 2px solid #3d1a1a;
      display: flex;
      align-items: center;
      gap: 16px;
    }
    .header-icon {
      width: 48px;
      height: 48px;
      border-radius: 50%;
      background: #2a0a0a;
      border: 2px solid #5a2a2a;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 24px;
      color: #ff4d4d;
      overflow: hidden;
    }
    .header-icon img { width: 100%; height: 100%; object-fit: cover; }
    .header-info { flex: 1; }
    .header-info h1 { color: #ff4d4d; font-size: 20px; font-weight: 700; }
    .header-info .subtitle { color: #a87a7a; font-size: 13px; }
    .header-badge {
      background: #3d1a1a;
      color: #ff4d4d;
      padding: 4px 14px;
      border-radius: 20px;
      font-size: 12px;
      font-weight: 600;
      border: 1px solid #5a2a2a;
    }
    .chat-area { padding: 20px 0; max-height: 600px; overflow-y: auto; background: #0d0505; }
    .chat-area::-webkit-scrollbar { width: 6px; }
    .chat-area::-webkit-scrollbar-track { background: #1a0a0a; }
    .chat-area::-webkit-scrollbar-thumb { background: #3d1a1a; border-radius: 3px; }
    .message { display: flex; padding: 8px 24px; gap: 12px; }
    .message:hover { background: rgba(255,255,255,0.03); }
    .message-avatar {
      width: 40px;
      height: 40px;
      border-radius: 50%;
      flex-shrink: 0;
      background: #2a1a1a;
      border: 1px solid #3d2a2a;
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: 700;
      font-size: 14px;
      color: #ff4d4d;
      text-transform: uppercase;
    }
    .message-content { flex: 1; min-width: 0; }
    .message-header { display: flex; align-items: baseline; gap: 10px; flex-wrap: wrap; }
    .message-author { color: #ff4d4d; font-weight: 600; font-size: 15px; }
    .message-time { color: #8a5a5a; font-size: 11px; }
    .message-text { color: #e8d5b0; font-size: 15px; line-height: 1.5; word-wrap: break-word; margin-top: 2px; }
    .system-message {
      text-align: center;
      padding: 8px 24px;
      color: #8a5a5a;
      font-size: 13px;
      font-style: italic;
      border-top: 1px solid #1a0a0a;
      border-bottom: 1px solid #1a0a0a;
    }
    .system-message .highlight { color: #ff4d4d; font-style: normal; font-weight: 600; }
    .footer {
      background: #1a0a0a;
      padding: 16px 24px;
      border-top: 1px solid #2a1a1a;
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
      gap: 10px;
    }
    .footer-info { color: #6a4a4a; font-size: 12px; }
    .footer-info strong { color: #ff4d4d; }
    .footer-ticket {
      background: #2a0a0a;
      color: #ff4d4d;
      padding: 4px 16px;
      border-radius: 12px;
      font-size: 12px;
      font-weight: 600;
      border: 1px solid #3d1a1a;
    }
    .bot-tag {
      background: #5a2a2a;
      color: #ff4d4d;
      font-size: 10px;
      padding: 1px 8px;
      border-radius: 10px;
      font-weight: 600;
      margin-left: 6px;
      border: 1px solid #8a3a3a;
    }
    @media (max-width: 600px) {
      .header { padding: 16px 20px; flex-wrap: wrap; }
      .header-info h1 { font-size: 17px; }
      .message { padding: 6px 16px; }
      .message-avatar { width: 32px; height: 32px; font-size: 12px; }
      .message-text { font-size: 14px; }
    }
  `;

  let messagesHTML = '';
  let messageCount = 0;
  
  const sortedMessages = messages.sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp));
  
  for (const msg of sortedMessages) {
    messageCount++;
    const isBot = msg.author?.bot || false;
    const authorName = msg.author?.username || 'Desconocido';
    const date = new Date(msg.timestamp).toLocaleString('es-MX', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
    const content = msg.content || '(Sin contenido)';
    const attachments = msg.attachments && msg.attachments.length > 0 
      ? msg.attachments.map(a => a.url).join(', ')
      : '';
    
    const initials = authorName.substring(0, 2).toUpperCase() || '??';
    const avatarColor = isBot ? '#5a2a2a' : '#2a1a1a';
    
    messagesHTML += `
      <div class="message">
        <div class="message-avatar" style="background: ${avatarColor};">${initials}</div>
        <div class="message-content">
          <div class="message-header">
            <span class="message-author">${escapeHTML(authorName)}</span>
            ${isBot ? '<span class="bot-tag">BOT</span>' : ''}
            <span class="message-time">${date}</span>
          </div>
          <div class="message-text">${escapeHTML(content)}</div>
          ${attachments ? `<div class="message-attachments"><span>📎 ${escapeHTML(attachments)}</span></div>` : ''}
        </div>
      </div>
    `;
  }

  if (messageCount === 0) {
    messagesHTML = `<div class="system-message"><span class="highlight">📭 No hay mensajes en este ticket.</span></div>`;
  }

  return `
    <!DOCTYPE html>
    <html lang="es">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Ticket ${ticketId} - Transcripción</title>
      <style>${styles}</style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <div class="header-icon"><img src="${avatarURL}" alt="Avatar"></div>
          <div class="header-info">
            <h1>🎫 ${escapeHTML(guildName)}</h1>
            <div class="subtitle">Transcripción del ticket #${ticketId}</div>
          </div>
          <div class="header-badge">${escapeHTML(channelName)}</div>
        </div>
        <div class="chat-area">
          <div class="system-message"><span class="highlight">📌 Inicio de la conversación</span></div>
          ${messagesHTML}
          <div class="system-message"><span class="highlight">🔒 Fin de la transcripción</span></div>
        </div>
        <div class="footer">
          <div class="footer-info">
            <strong>${messageCount}</strong> mensajes • 
            Canal: <strong>#${escapeHTML(channelName)}</strong> • 
            ID: <strong>${channelId}</strong>
          </div>
          <div class="footer-ticket">🎫 ${ticketId}</div>
        </div>
      </div>
    </body>
    </html>
  `;
}

// ==================== PANEL DE TICKETS ====================
function categoryListText() {
  return Object.values(CATEGORIES).map((c) => `${c.emoji} **${c.description}** — ${c.menuDescription}`).join('\n');
}

function panelEmbed() {
  return new EmbedBuilder()
    .setColor('#2EC4C4')
    .setTitle('🎫 𝐑𝐄𝐀𝐂𝐇𝐒𝐔𝐑𝐕𝐈𝐕𝐀𝐋 𝐓𝐈𝐂𝐊𝐄𝐓𝐒 — 𝐒𝐈𝐒𝐓𝐄𝐌𝐀 𝐃𝐄 𝐓𝐈𝐂𝐊𝐄𝐓𝐒')
    .setDescription(
      '> *¡Bienvenido al sistema de atención al jugador de 𝐑𝐄𝐀𝐂𝐇𝐒𝐔𝐑𝐕𝐈𝐕𝐀𝐋 𝐓𝐈𝐂𝐊𝐄𝐓𝐒!*\n\n' +
      '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n' +
      '📌 **¿Cómo funciona?**\n' +
      '• Selecciona una categoría del menú desplegable\n' +
      '• Responde las preguntas del formulario\n' +
      '• Nuestro equipo te atenderá lo antes posible\n\n' +
      '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n' +
      '📂 **Categorías disponibles:**\n\n' +
      categoryListText() + '\n\n' +
      '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n' +
      '⚡ **¡Elige una opción y te atenderemos inmediatamente!** ⚡'
    )
    // ⚠️ Falta el link CDN del logo de ReachSurvival Tickets: descomenta y pega el link cuando lo tengas
    // .setImage('PON_AQUI_EL_LINK_DEL_LOGO')
    .setFooter({ text: '𝐑𝐄𝐀𝐂𝐇𝐒𝐔𝐑𝐕𝐈𝐕𝐀𝐋 𝐓𝐈𝐂𝐊𝐄𝐓𝐒 — Tu mundo, tu aventura | Sistema de Tickets v2.0' })
    .setTimestamp();
}

function panelComponents() {
  const menu = new StringSelectMenuBuilder()
    .setCustomId('ticket_menu')
    .setPlaceholder('🔽 Selecciona una categoría...')
    .addOptions(
      Object.entries(CATEGORIES).map(([key, c]) => ({
        label: `${c.emoji} ${c.description}`,
        description: c.menuDescription.slice(0, 100),
        value: key
      }))
    );
  return [new ActionRowBuilder().addComponents(menu)];
}

function controlsRows(channelId) {
  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('claim_' + channelId).setLabel('📌 Reclamar').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId('unclaim_' + channelId).setLabel('⏪ Desreclamar').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('transfer_' + channelId).setLabel('🔄 Transferir').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId('priority_' + channelId).setLabel('⭐ Priorizar').setStyle(ButtonStyle.Danger)
  );
  const row2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('note_' + channelId).setLabel('📝 Nota interna').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('remind_' + channelId).setLabel('🔔 Recordatorio').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId('staff_close_' + channelId).setLabel('🔒 Cerrar (Staff)').setStyle(ButtonStyle.Danger)
  );
  const row3 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('user_remind_' + channelId).setLabel('⏰ Pedir atención').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('user_close_' + channelId).setLabel('🔒 Cerrar ticket').setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId('add_user_' + channelId).setLabel('➕ Agregar Usuario').setStyle(ButtonStyle.Success)
  );
  const row4 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('add_staff_' + channelId).setLabel('👑 Agregar Staff').setStyle(ButtonStyle.Primary)
  );
  return [row1, row2, row3, row4];
}

// ==================== COMANDOS ====================
const commands = [
  new SlashCommandBuilder().setName('ticketpanel').setDescription('Publica el panel de tickets en este canal (solo staff)')
].map((c) => c.toJSON());

async function registerCommands() {
  const rest = new REST({ version: '10' }).setToken(config.token);
  await rest.put(Routes.applicationGuildCommands(config.clientId, config.guildId), { body: commands });
  console.log('✅ Comandos slash registrados en el servidor.');
}

async function ensurePanel() {
  if (!config.panelChannelId || config.panelChannelId.startsWith('PON_AQUI')) return;
  const channel = await client.channels.fetch(config.panelChannelId).catch((err) => {
    console.error('❌ No pude acceder a panelChannelId:', err.message); return null;
  });
  if (!channel) return;
  const recent = await channel.messages.fetch({ limit: 50 }).catch(() => null);
  const alreadyPosted = recent?.some(
    (m) => m.author.id === client.user.id && m.embeds[0]?.title === '🎫 𝐑𝐄𝐀𝐂𝐇𝐒𝐔𝐑𝐕𝐈𝐕𝐀𝐋 𝐓𝐈𝐂𝐊𝐄𝐓𝐒 — 𝐒𝐈𝐒𝐓𝐄𝐌𝐀 𝐃𝐄 𝐓𝐈𝐂𝐊𝐄𝐓𝐒'
  );
  if (alreadyPosted) { console.log('ℹ️ El panel ya estaba publicado, no se duplica.'); return; }
  await channel.send({ embeds: [panelEmbed()], components: panelComponents() });
  console.log('✅ Panel de tickets publicado automáticamente en #' + channel.name);
}

async function recoverOrphanedTickets() {
  console.log('🔍 Recuperando tickets huérfanos...');
  try {
    const tickets = await db.all('SELECT * FROM tickets WHERE status = "open"', []);
    let recovered = 0;
    for (const ticket of tickets) {
      try {
        const channel = await client.channels.fetch(ticket.channelId);
        if (!channel) {
          await db.run('UPDATE tickets SET status = "closed", closedAt = CURRENT_TIMESTAMP, closeReason = ? WHERE channelId = ?',
            ['Recuperado por sistema (canal eliminado)', ticket.channelId]);
          recovered++;
          console.log(`🔒 Ticket ${ticket.ticketId} recuperado (canal eliminado)`);
        }
      } catch (error) {
        await db.run('UPDATE tickets SET status = "closed", closedAt = CURRENT_TIMESTAMP, closeReason = ? WHERE channelId = ?',
          ['Recuperado por sistema (canal no encontrado)', ticket.channelId]);
        recovered++;
        console.log(`🔒 Ticket ${ticket.ticketId} recuperado (canal no encontrado)`);
      }
    }
    if (recovered > 0) console.log(`✅ ${recovered} tickets huérfanos recuperados.`);
  } catch (error) {
    console.error('❌ Error en recoverOrphanedTickets:', error.message);
  }
}

// ==================== EVENTOS ====================
client.once('ready', async () => {
  console.log(`✅ Bot conectado como ${client.user.tag}`);
  try { await recoverOrphanedTickets(); } catch (err) { console.error('❌ Error recuperando tickets huérfanos:', err.message); }
  try { await registerCommands(); } catch (err) { console.error('❌ Error registrando comandos:', err.message); }
  try { await ensurePanel(); } catch (err) { console.error('❌ Error publicando el panel automático:', err.message); }
});

client.on('messageCreate', async (message) => {
  if (message.author.bot || !message.guild || !message.channel.name?.startsWith('ticket-')) return;
  
  // 🔥 VERIFICAR MENCIONES A STAFF
  await checkStaffMentions(message);
  
  if (isStaff(message.member)) {
    const fakeInteraction = { member: message.member, channel: message.channel, user: message.author, guild: message.guild };
    await checkAndWarnStaff(fakeInteraction);
  }
});

client.on('interactionCreate', async (interaction) => {
  try {
    if (interaction.isChatInputCommand()) {
      if (interaction.commandName === 'ticketpanel') {
        if (!isStaff(interaction.member)) {
          return interaction.reply({ content: '❌ Solo el staff puede crear el panel.', ephemeral: true });
        }
        await interaction.channel.send({ embeds: [panelEmbed()], components: panelComponents() });
        return interaction.reply({ content: '✅ Panel de tickets creado.', ephemeral: true });
      }
    }
    if (interaction.isStringSelectMenu() && interaction.customId === 'ticket_menu') {
      return showTicketModal(interaction, interaction.values[0]);
    }
    if (interaction.isButton()) return handleButton(interaction);
    if (interaction.isModalSubmit()) return handleModal(interaction);
  } catch (err) {
    console.error('❌ Error manejando interacción:', err);
    const payload = { content: '❌ Ocurrió un error: ' + err.message, ephemeral: true };
    if (interaction.deferred || interaction.replied) {
      await interaction.editReply(payload).catch(() => {});
    } else {
      await interaction.reply(payload).catch(() => {});
    }
  }
});

// ==================== MODAL: CREAR TICKET ====================
function showTicketModal(interaction, categoryKey) {
  const category = CATEGORIES[categoryKey] || { description: 'General' };
  const modal = new ModalBuilder()
    .setCustomId('ticket_create_' + categoryKey)
    .setTitle(('📋 ' + category.description).slice(0, 45));
  
  const rows = questionsFor(categoryKey).slice(0, 5).map((q) => {
    const input = new TextInputBuilder()
      .setCustomId(q.id)
      .setLabel(q.label.slice(0, 45))
      .setStyle(q.style)
      .setMinLength(11)
      .setMaxLength(q.style === TextInputStyle.Paragraph ? 2000 : 100)
      .setRequired(true);
    return new ActionRowBuilder().addComponents(input);
  });
  modal.addComponents(...rows);
  return interaction.showModal(modal);
}

// ==================== HANDLE MODAL ====================
async function handleModal(interaction) {
  const customId = interaction.customId;
  
  try {
    if (customId.startsWith('ticket_create_')) {
      await interaction.deferReply({ ephemeral: true });
      await createTicket(interaction, customId.replace('ticket_create_', ''));
      return;
    }
    if (customId.startsWith('transfer_modal_')) {
      if (!isStaff(interaction.member)) {
        return interaction.reply({ content: '❌ Solo el staff puede transferir tickets.', ephemeral: true });
      }
      await interaction.deferReply({ ephemeral: true });
      await transferTicket(interaction, customId.replace('transfer_modal_', ''));
      return;
    }
    if (customId.startsWith('note_modal_')) {
      if (!isStaff(interaction.member)) {
        return interaction.reply({ content: '❌ Solo el staff puede crear notas internas.', ephemeral: true });
      }
      await interaction.deferReply({ ephemeral: true });
      await addInternalNote(interaction, customId.replace('note_modal_', ''));
      return;
    }
    if (customId.startsWith('add_staff_modal_')) {
      if (!isAdmin(interaction.member)) {
        return interaction.reply({ content: '❌ Solo administradores pueden agregar staff.', ephemeral: true });
      }
      await interaction.deferReply({ ephemeral: true });
      await addStaffToTicket(interaction, customId.replace('add_staff_modal_', ''));
      return;
    }
    if (customId.startsWith('add_user_modal_')) {
      await interaction.deferReply({ ephemeral: true });
      await addUserToTicket(interaction, customId.replace('add_user_modal_', ''));
      return;
    }
  } catch (error) {
    console.error('❌ Error en handleModal:', error);
    try {
      await interaction.editReply({ 
        content: `❌ Error: ${error.message}`,
        ephemeral: true 
      });
    } catch (e) {
      console.error('❌ Error al responder:', e);
    }
  }
}

// ==================== CREAR TICKET ====================
async function createTicket(interaction, categoryKey) {
  try {
    const category = CATEGORIES[categoryKey] || { 
      roles: [], 
      description: 'General', 
      emoji: '🎫', 
      categoryId: DEFAULT_CATEGORY_ID 
    };
    const user = interaction.user;
    const guild = interaction.guild;
    
    const isAdminUser = interaction.member.permissions.has(PermissionsBitField.Flags.Administrator);
    const isOwner = config.owners && config.owners.includes(user.id);
    const isStaffMember = isStaff(interaction.member);
    
    let newCount = 0;
    let limitText = '';
    
    if (isAdminUser || isOwner || isStaffMember) {
      const count = await getOpenTicketsCount(user.id);
      newCount = count + 1;
      limitText = `\n📊 **Tickets abiertos:** ${newCount} (sin límite)`;
    } else {
      const currentTickets = await getActualOpenTickets(user.id, interaction.guild);
      if (currentTickets >= 3) {
        await interaction.editReply({ 
          content: '❌ Has alcanzado el límite máximo de **3 tickets abiertos**. Cierra uno antes de abrir otro.',
          ephemeral: true 
        });
        return;
      }
      newCount = currentTickets + 1;
      limitText = `\n📊 **Tickets abiertos:** ${newCount}/3`;
    }

    const answers = questionsFor(categoryKey).map((q) => {
      const value = interaction.fields.getTextInputValue(q.id) || 'Sin respuesta';
      return `**${q.label}:**\n${value}`;
    }).join('\n\n');

    const categoryId = category.categoryId || DEFAULT_CATEGORY_ID;
    
    const userPermissions = [
      PermissionFlagsBits.ViewChannel,
      PermissionFlagsBits.SendMessages,
      PermissionFlagsBits.ReadMessageHistory,
      PermissionFlagsBits.AttachFiles
    ];
    
    const staffPermissions = [
      PermissionFlagsBits.ViewChannel,
      PermissionFlagsBits.SendMessages,
      PermissionFlagsBits.ReadMessageHistory,
      PermissionFlagsBits.ManageMessages,
      PermissionFlagsBits.AttachFiles
    ];

    const ticketRolePermissions = [
      PermissionFlagsBits.ViewChannel,
      PermissionFlagsBits.SendMessages,
      PermissionFlagsBits.ReadMessageHistory
    ];

    const permissionOverwrites = [
      { id: guild.id, deny: [PermissionFlagsBits.ViewChannel] },
      { id: user.id, allow: userPermissions }
    ];

    for (const staffRoleId of STAFF_ROLE_IDS) {
      try {
        const staffRole = await guild.roles.fetch(staffRoleId);
        if (staffRole) {
          permissionOverwrites.push({ id: staffRoleId, allow: staffPermissions });
        }
      } catch (e) {
        console.log(`⚠️ Rol de staff no encontrado (${staffRoleId}): ${e.message}`);
      }
    }

    try {
      const ticketRole = await guild.roles.fetch(TICKET_ROLE_ID);
      if (ticketRole) {
        permissionOverwrites.push({ id: TICKET_ROLE_ID, allow: ticketRolePermissions });
        console.log(`✅ Rol de tickets encontrado: ${ticketRole.name}`);
      } else {
        console.log(`⚠️ Rol de tickets (${TICKET_ROLE_ID}) no encontrado.`);
      }
    } catch (e) {
      console.log(`⚠️ No se pudo verificar el rol de tickets: ${e.message}`);
    }

    const categoryShort = category.description.toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 15);
    const userName = channelNameFor(user).replace('ticket-', '');
    const channelName = `ticket-${categoryShort}-${userName}`.slice(0, 90);

    console.log('🔍 Creando canal:');
    console.log(`  - Nombre: ${channelName}`);
    console.log(`  - Categoría: ${category.description}`);
    console.log(`  - Usuario: ${user.username}`);

    const channel = await guild.channels.create({
      name: channelName,
      type: ChannelType.GuildText,
      parent: categoryId,
      permissionOverwrites: permissionOverwrites,
      topic: `Ticket de ${user.username} - ${category.description} (${categoryKey})`
    });

    const ticketId = makeTicketId();
    await db.run(
      'INSERT INTO tickets (ticketId, userId, channelId, category, answers) VALUES (?, ?, ?, ?, ?)',
      [ticketId, user.id, channel.id, categoryKey, answers]
    );
    await addLog(ticketId, 'creado', user.id, categoryKey);

    const roleMentions = category.roles.map((id) => `<@&${id}>`).join(' ');
    const ticketRoleMention = `<@&${TICKET_ROLE_ID}>`;
    
    const welcomeEmbed = new EmbedBuilder()
      .setColor(0xF39C12)
      .setTitle(`${category.emoji} Nuevo ticket — ${category.description}`)
      .setDescription(trimText(
        `> *¡Gracias por abrir un ticket! Nuestro equipo te atenderá a la brevedad.*\n\n` +
        `📋 **Respuestas del formulario:**\n${answers}\n\n` +
        `⏳ *Por favor espera la respuesta de un miembro del staff.*${limitText}`,
        4000
      ))
      .addFields(
        { name: '📂 Categoría', value: `${category.emoji} ${category.description}`, inline: true },
        { name: '👤 Creado por', value: `<@${user.id}>`, inline: true },
        { name: '🆔 Ticket ID', value: ticketId, inline: true }
      )
      .setFooter({ text: `Ticket #${ticketId}` })
      .setTimestamp();

    await channel.send({
      content: `${ticketRoleMention} | <@${user.id}>${roleMentions ? ' ' + roleMentions : ''}`,
      embeds: [welcomeEmbed],
      components: controlsRows(channel.id),
      allowed_mentions: { 
        parse: [], 
        users: [user.id], 
        roles: [TICKET_ROLE_ID] 
      }
    });

    const replyText = isAdminUser || isOwner || isStaffMember 
      ? `✅ ¡Ticket creado! (${newCount} tickets abiertos - sin límite)\n📂 Categoría: ${category.emoji} ${category.description}\nVe a <#${channel.id}> para continuar.`
      : `✅ ¡Ticket creado! (${newCount}/3 activos)\n📂 Categoría: ${category.emoji} ${category.description}\nVe a <#${channel.id}> para continuar.`;

    await interaction.editReply({ 
      content: replyText,
      ephemeral: true 
    });

  } catch (error) {
    console.error('❌ Error en createTicket:', error);
    try {
      await interaction.editReply({ 
        content: `❌ Error al crear el ticket: ${error.message}`,
        ephemeral: true 
      });
    } catch (e) {
      console.error('❌ Error al responder:', e);
    }
    throw error;
  }
}

// ==================== AGREGAR STAFF ====================
async function showAddStaffModal(interaction, channelId) {
  if (!isAdmin(interaction.member)) {
    return interaction.reply({ content: '❌ Solo administradores pueden agregar staff.', ephemeral: true });
  }
  const modal = new ModalBuilder()
    .setCustomId('add_staff_modal_' + channelId)
    .setTitle('👑 Agregar Staff')
    .addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('user_id')
          .setLabel('ID del usuario')
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
          .setMinLength(15)
          .setMaxLength(25)
          .setPlaceholder('Ej: 123456789012345678')
      )
    );
  return interaction.showModal(modal);
}

async function addStaffToTicket(interaction, channelId) {
  const userId = interaction.fields.getTextInputValue('user_id').replace(/\D/g, '');
  if (!userId) {
    return interaction.editReply({ content: '❌ ID inválido.', ephemeral: true });
  }
  
  const targetMember = await interaction.guild.members.fetch(userId).catch(() => null);
  if (!targetMember) {
    return interaction.editReply({ content: '❌ Usuario no encontrado.', ephemeral: true });
  }
  
  try {
    await interaction.channel.permissionOverwrites.create(userId, {
      ViewChannel: true,
      SendMessages: true,
      ReadMessageHistory: true,
      ManageMessages: true,
      AttachFiles: true
    });
    
    const embed = new EmbedBuilder()
      .setColor(0x2EC4C4)
      .setTitle('👑 Staff agregado al ticket')
      .setDescription(`<@${userId}> ha sido agregado como staff al ticket por **${interaction.user.username}**.`)
      .setTimestamp();
    await interaction.channel.send({ embeds: [embed] });
    await addLog(await getTicketIdByChannel(interaction, channelId), 'staff_agregado', interaction.user.id, `Staff: ${userId}`);
    return interaction.editReply({ content: `✅ <@${userId}> ha sido agregado como staff al ticket.`, ephemeral: true });
  } catch (error) {
    return interaction.editReply({ content: `❌ Error al agregar staff: ${error.message}`, ephemeral: true });
  }
}

// ==================== AGREGAR USUARIO ====================
async function showAddUserModal(interaction, channelId) {
  const modal = new ModalBuilder()
    .setCustomId('add_user_modal_' + channelId)
    .setTitle('➕ Agregar Usuario')
    .addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('user_id')
          .setLabel('ID del usuario')
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
          .setMinLength(15)
          .setMaxLength(25)
          .setPlaceholder('Ej: 123456789012345678')
      )
    );
  return interaction.showModal(modal);
}

async function addUserToTicket(interaction, channelId) {
  const userId = interaction.fields.getTextInputValue('user_id').replace(/\D/g, '');
  if (!userId) {
    return interaction.editReply({ content: '❌ ID inválido.', ephemeral: true });
  }
  
  const targetMember = await interaction.guild.members.fetch(userId).catch(() => null);
  if (!targetMember) {
    return interaction.editReply({ content: '❌ Usuario no encontrado.', ephemeral: true });
  }
  
  try {
    await interaction.channel.permissionOverwrites.create(userId, {
      ViewChannel: true,
      SendMessages: true,
      ReadMessageHistory: true,
      AttachFiles: true
    });
    
    const embed = new EmbedBuilder()
      .setColor(0x2ecc71)
      .setTitle('➕ Usuario agregado al ticket')
      .setDescription(`<@${userId}> ha sido agregado al ticket por **${interaction.user.username}**.`)
      .setTimestamp();
    await interaction.channel.send({ embeds: [embed] });
    await addLog(await getTicketIdByChannel(interaction, channelId), 'usuario_agregado', interaction.user.id, `Usuario: ${userId}`);
    return interaction.editReply({ content: `✅ <@${userId}> ha sido agregado al ticket.`, ephemeral: true });
  } catch (error) {
    return interaction.editReply({ content: `❌ Error al agregar usuario: ${error.message}`, ephemeral: true });
  }
}

// ==================== BOTONES ====================
function parseCustomId(customId) {
  const prefixes = ['confirm_staff_close_', 'confirm_user_close_', 'cancel_close_', 'accept_transfer_', 'reject_transfer_', 'user_remind_', 'user_close_', 'staff_close_', 'add_staff_', 'add_user_'];
  const prefix = prefixes.find((p) => customId.startsWith(p));
  if (prefix) return { action: prefix.slice(0, -1), channelId: customId.slice(prefix.length) };
  const idx = customId.indexOf('_');
  if (idx === -1) return { action: customId, channelId: '' };
  return { action: customId.slice(0, idx), channelId: customId.slice(idx + 1) };
}

async function handleButton(interaction) {
  const { action, channelId } = parseCustomId(interaction.customId);
  
  if (action === 'add_staff') return showAddStaffModal(interaction, channelId);
  if (action === 'add_user') return showAddUserModal(interaction, channelId);
  
  const staffOnly = ['claim', 'unclaim', 'transfer', 'priority', 'note', 'remind', 'staff_close', 'confirm_staff_close'];
  if (staffOnly.includes(action) && !isStaff(interaction.member)) {
    return interaction.reply({ content: '❌ Solo el staff puede usar esta acción.', ephemeral: true });
  }
  
  if (action === 'transfer') return showTransferModal(interaction, channelId);
  if (action === 'note') return showNoteModal(interaction, channelId);
  if (action === 'staff_close') return showStaffCloseConfirm(interaction, channelId);
  
  if (action === 'user_remind') {
    const ticket = await requireTicket(channelId);
    const isCreator = ticket && ticket.userId === interaction.user.id;
    const isStaffMember = isStaff(interaction.member);
    if (!isCreator && !isStaffMember) {
      return interaction.reply({ content: '❌ Solo el creador del ticket o el staff pueden usar esto.', ephemeral: true });
    }
    return userReminder(interaction, channelId);
  }
  
  if (action === 'user_close') {
    const ticket = await requireTicket(channelId);
    const isCreator = ticket && ticket.userId === interaction.user.id;
    const hasRole = interaction.member.roles.cache.has(USER_CLOSE_ROLE_ID) || 
                    interaction.member.roles.cache.has(NORMAL_USER_ROLE_ID);
    const isStaffMember = isStaff(interaction.member);
    if (!isCreator && !hasRole && !isStaffMember) {
      return interaction.reply({ content: '❌ No tienes permiso para cerrar este ticket.', ephemeral: true });
    }
    return showUserCloseConfirm(interaction, channelId);
  }
  
  if (action === 'cancel_close') {
    await interaction.update({ content: '❌ Cierre cancelado.', embeds: [], components: [] });
    return;
  }
  
  if (action === 'confirm_staff_close') {
    await interaction.deferReply({ ephemeral: true });
    await interaction.editReply({ content: '🔒 **Este ticket se cerrará en 5 segundos...**\n⏳ Generando transcripción...' });
    const pendingTime = Date.now() + 5000;
    await db.run('UPDATE tickets SET pendingClose = ? WHERE channelId = ?', [pendingTime, channelId]);
    await new Promise(resolve => setTimeout(resolve, 5000));
    const ticket = await requireTicket(channelId);
    await closeTicket(channelId, ticket.ticketId, interaction.user, 'Cerrado por staff', interaction);
    return;
  }
  
  if (action === 'confirm_user_close') {
    await interaction.deferReply({ ephemeral: true });
    await interaction.editReply({ content: '🔒 **Este ticket se cerrará en 5 segundos...**\n⏳ Generando transcripción...' });
    const pendingTime = Date.now() + 5000;
    await db.run('UPDATE tickets SET pendingClose = ? WHERE channelId = ?', [pendingTime, channelId]);
    await new Promise(resolve => setTimeout(resolve, 5000));
    const ticket = await requireTicket(channelId);
    await closeTicket(channelId, ticket.ticketId, interaction.user, 'Cerrado por el usuario', interaction);
    return;
  }

  await interaction.deferReply({ ephemeral: true });
  
  if (action === 'claim') return claimTicket(interaction, channelId);
  if (action === 'unclaim') return unclaimTicket(interaction, channelId);
  if (action === 'priority') return cyclePriority(interaction, channelId);
  if (action === 'remind') return staffReminder(interaction, channelId);
  if (action === 'accept_transfer' || action === 'reject_transfer') return transferAnswer(interaction, action, channelId);
  
  return interaction.editReply({ content: '❌ Acción no reconocida.', ephemeral: true });
}

// ==================== FUNCIONES DE STAFF ====================
async function claimTicket(interaction, channelId) {
  const ticket = await requireTicket(channelId);
  if (ticket.claimedBy !== null && ticket.claimedBy !== interaction.user.id) {
    return interaction.editReply({ content: `❌ Este ticket ya fue reclamado por <@${ticket.claimedBy}>.`, ephemeral: true });
  }
  if (ticket.claimedBy === interaction.user.id) {
    return interaction.editReply({ content: `❌ Ya has reclamado este ticket.`, ephemeral: true });
  }
  await db.run('UPDATE tickets SET claimedBy = ? WHERE channelId = ?', [interaction.user.id, channelId]);
  await addLog(ticket.ticketId, 'reclamado', interaction.user.id);
  const embed = new EmbedBuilder()
    .setColor(0x2ecc71)
    .setTitle('📌 Ticket reclamado')
    .setDescription(`El ticket fue reclamado por **${interaction.user.username}**.`);
  await interaction.channel.send({ embeds: [embed] });
  return interaction.editReply({ content: '✅ Ticket reclamado correctamente.', ephemeral: true });
}

async function unclaimTicket(interaction, channelId) {
  const ticket = await requireTicket(channelId);
  if (ticket.claimedBy === null) {
    return interaction.editReply({ content: '❌ Este ticket no está reclamado actualmente.', ephemeral: true });
  }
  if (ticket.claimedBy !== interaction.user.id) {
    return interaction.editReply({ content: '❌ Solo el staff que reclamó el ticket puede desreclamarlo.', ephemeral: true });
  }
  await db.run('UPDATE tickets SET claimedBy = NULL WHERE channelId = ?', [channelId]);
  await addLog(ticket.ticketId, 'desreclamado', interaction.user.id);
  const embed = new EmbedBuilder()
    .setColor(0xf1c40f)
    .setTitle('⏪ Ticket desreclamado')
    .setDescription(`El ticket fue desreclamado por **${interaction.user.username}**.`);
  await interaction.channel.send({ embeds: [embed] });
  return interaction.editReply({ content: '✅ Ticket desreclamado correctamente.', ephemeral: true });
}

async function cyclePriority(interaction, channelId) {
  const ticket = await requireTicket(channelId);
  const priorities = ['normal', 'alta', 'urgente'];
  const next = priorities[(priorities.indexOf(ticket.priority || 'normal') + 1) % priorities.length];
  await db.run('UPDATE tickets SET priority = ? WHERE channelId = ?', [next, channelId]);
  await addLog(ticket.ticketId, 'prioridad_cambiada', interaction.user.id, 'Nueva: ' + next);
  const embed = new EmbedBuilder()
    .setColor(0x2EC4C4)
    .setTitle('⭐ Prioridad actualizada')
    .setDescription(`La prioridad ahora es **${next.toUpperCase()}**.`);
  return interaction.editReply({ embeds: [embed], ephemeral: true });
}

// ==================== TRANSFERENCIA ====================
async function showTransferModal(interaction, channelId) {
  const modal = new ModalBuilder()
    .setCustomId('transfer_modal_' + channelId)
    .setTitle('🔄 Transferir ticket')
    .addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('target_user')
          .setLabel('ID del staff')
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
          .setMinLength(15)
          .setMaxLength(25)
          .setPlaceholder('Ej: 123456789012345678')
      )
    );
  return interaction.showModal(modal);
}

async function transferTicket(interaction, channelId) {
  const ticket = await requireTicket(channelId);
  const targetId = interaction.fields.getTextInputValue('target_user').replace(/\D/g, '');
  if (!targetId) {
    return interaction.editReply({ content: '❌ Debes escribir el ID numérico del staff.', ephemeral: true });
  }
  if (ticket.claimedBy !== interaction.user.id) {
    return interaction.editReply({ content: '❌ No tienes el reclamo de este ticket. Debes reclamarlo antes de transferir.', ephemeral: true });
  }
  const targetMember = await interaction.guild.members.fetch(targetId).catch(() => null);
  if (!targetMember) {
    return interaction.editReply({ content: '❌ Usuario no encontrado.', ephemeral: true });
  }
  if (!STAFF_ROLE_IDS.some((id) => targetMember.roles.cache.has(id)) && !targetMember.permissions.has(PermissionsBitField.Flags.Administrator)) {
    return interaction.editReply({ content: '❌ Ese usuario no tiene el rol de staff configurado.', ephemeral: true });
  }
  await db.run('UPDATE tickets SET transferTo = ? WHERE channelId = ?', [targetId, channelId]);
  const embed = new EmbedBuilder()
    .setColor(0xe67e22)
    .setTitle('🔄 Solicitud de transferencia')
    .setDescription(`<@${interaction.user.id}> quiere transferirte el ticket <#${channelId}>.`)
    .addFields(
      { name: '📋 Ticket', value: `<#${channelId}>`, inline: true },
      { name: '👤 Staff que transfiere', value: `<@${interaction.user.id}>`, inline: true },
      { name: '📌 Estado', value: 'Acepta para tomar el reclamo', inline: true }
    )
    .setFooter({ text: `Ticket ID: ${ticket.ticketId}` })
    .setTimestamp();
  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('accept_transfer_' + channelId).setLabel('✅ Aceptar').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId('reject_transfer_' + channelId).setLabel('❌ Rechazar').setStyle(ButtonStyle.Danger)
  );
  try {
    await targetMember.send({ embeds: [embed], components: [row] });
    await addLog(ticket.ticketId, 'transferencia_solicitada', interaction.user.id, `Destino: ${targetId}`);
    const channelEmbed = new EmbedBuilder()
      .setColor(0xe67e22)
      .setTitle('🔄 Solicitud de transferencia enviada')
      .setDescription(`<@${interaction.user.id}> ha solicitado transferir el ticket a <@${targetId}>.`)
      .addFields(
        { name: '⏳ Estado', value: 'Esperando respuesta...', inline: true },
        { name: '📌 Acción', value: 'El staff destino debe aceptar o rechazar', inline: true }
      )
      .setTimestamp();
    await interaction.channel.send({ embeds: [channelEmbed] });
    return interaction.editReply({ content: `✅ Solicitud de transferencia enviada a <@${targetId}>.`, ephemeral: true });
  } catch (error) {
    return interaction.editReply({ content: '❌ No se pudo enviar el DM (el usuario tiene los DMs cerrados).', ephemeral: true });
  }
}

async function transferAnswer(interaction, action, channelId) {
  const ticket = await requireTicket(channelId);
  const accepted = action === 'accept_transfer';
  const userId = interaction.member?.user?.id || interaction.user?.id;
  const userTag = interaction.member?.user?.username || interaction.user?.username;
  if (ticket.transferTo !== userId) {
    return interaction.editReply({ content: '❌ Esta solicitud de transferencia no es para ti.', ephemeral: true });
  }
  if (accepted) {
    await db.run('UPDATE tickets SET claimedBy = ?, transferTo = NULL WHERE channelId = ?', [userId, channelId]);
    await addLog(ticket.ticketId, 'transferencia_aceptada', userId);
    const channel = await client.channels.fetch(channelId).catch(() => null);
    if (channel) {
      const embed = new EmbedBuilder()
        .setColor(0x2ecc71)
        .setTitle('✅ Transferencia aceptada')
        .setDescription(`**${userTag}** aceptó la transferencia del ticket.`)
        .addFields(
          { name: '📋 Nuevo responsable', value: `<@${userId}>`, inline: true },
          { name: '👤 Anterior responsable', value: `<@${ticket.claimedBy}>`, inline: true }
        )
        .setTimestamp();
      await channel.send({ embeds: [embed] });
    }
    return interaction.editReply({ content: '✅ Has aceptado la transferencia. Ahora eres el responsable del ticket.', ephemeral: true });
  } else {
    await db.run('UPDATE tickets SET transferTo = NULL WHERE channelId = ?', [channelId]);
    await addLog(ticket.ticketId, 'transferencia_rechazada', userId);
    const channel = await client.channels.fetch(channelId).catch(() => null);
    if (channel) {
      const embed = new EmbedBuilder()
        .setColor(0xe74c3c)
        .setTitle('❌ Transferencia rechazada')
        .setDescription(`**${userTag}** rechazó la transferencia del ticket.`)
        .addFields({ name: '📋 Responsable actual', value: `<@${ticket.claimedBy}>`, inline: true })
        .setTimestamp();
      await channel.send({ embeds: [embed] });
    }
    return interaction.editReply({ content: '❌ Has rechazado la transferencia.', ephemeral: true });
  }
}

// ==================== FUNCIÓN USER REMINDER (CORREGIDA) ====================
async function userReminder(interaction, channelId) {
  const ticket = await requireTicket(channelId);
  const count = (ticket.userReminderCount || 0) + 1;
  if (count > 3) {
    return interaction.reply({ content: '❌ Límite de 3 recordatorios alcanzado.', ephemeral: true });
  }
  await db.run('UPDATE tickets SET userReminderCount = ? WHERE channelId = ?', [count, channelId]);
  await addLog(ticket.ticketId, 'recordatorio_usuario', interaction.user.id, 'Count: ' + count);
  
  // 🔥 CAMBIADO: Etiquetar al rol de tickets
  const ticketRoleMention = `<@&${TICKET_ROLE_ID}>`;
  await interaction.channel.send({ 
    content: `🔔 **<@${interaction.user.id}> solicita atención!** (${count}/3)\n${ticketRoleMention}`,
    allowed_mentions: { 
      parse: [], 
      users: [interaction.user.id], 
      roles: [TICKET_ROLE_ID] 
    }
  });
  
  const embed = new EmbedBuilder()
    .setColor(0xe67e22)
    .setTitle('⏰ Recordatorio solicitado')
    .setDescription(`Has solicitado atención para tu ticket. (${count}/3)`);
  return interaction.reply({ embeds: [embed], ephemeral: true });
}

// ==================== STAFF REMINDER ====================
async function staffReminder(interaction, channelId) {
  const ticket = await requireTicket(channelId);
  const count = (ticket.reminderCount || 0) + 1;
  await db.run('UPDATE tickets SET reminderCount = ? WHERE channelId = ?', [count, channelId]);
  await addLog(ticket.ticketId, 'recordatorio_enviado', interaction.user.id, 'Count: ' + count);
  let warningMessage = '', color = 0xf1c40f;
  if (count === 2) {
    warningMessage = '⚠️ **Este es el segundo recordatorio.** Si no respondes, el ticket se cerrará automáticamente en el próximo.';
    color = 0xe67e22;
  } else if (count >= 3) {
    warningMessage = '⛔ **¡ÚLTIMO AVISO!** Este ticket se cerrará automáticamente en 5 segundos.';
    color = 0xe74c3c;
  } else {
    warningMessage = '📌 Responde en tu ticket para continuar con tu solicitud.';
  }
  try {
    const targetUser = await client.users.fetch(ticket.userId);
    const dmEmbed = new EmbedBuilder()
      .setColor(color)
      .setTitle('🔔 Recordatorio del staff sobre tu ticket')
      .setDescription(`Has recibido un recordatorio sobre tu ticket en **𝐑𝐄𝐀𝐂𝐇𝐒𝐔𝐑𝐕𝐈𝐕𝐀𝐋 𝐓𝐈𝐂𝐊𝐄𝐓𝐒**.`)
      .addFields(
        { name: '📋 Ticket', value: `<#${channelId}>`, inline: true },
        { name: '👤 Staff', value: `<@${interaction.user.id}>`, inline: true },
        { name: '📊 Recordatorio', value: `**${count}/3**`, inline: true },
        { name: '📌 Acción requerida', value: warningMessage, inline: false }
      )
      .setFooter({ text: `𝐑𝐄𝐀𝐂𝐇𝐒𝐔𝐑𝐕𝐈𝐕𝐀𝐋 𝐓𝐈𝐂𝐊𝐄𝐓𝐒 — Sistema de Tickets | Recordatorio ${count}/3` })
      .setTimestamp();
    await targetUser.send({ embeds: [dmEmbed] });
    const confirmEmbed = new EmbedBuilder()
      .setColor(0xf1c40f)
      .setTitle('🔔 Recordatorio enviado')
      .setDescription(`Se ha enviado un recordatorio al usuario. (${count}/3)`)
      .addFields(
        { name: '👤 Usuario', value: `<@${ticket.userId}>`, inline: true },
        { name: '📋 Ticket', value: `<#${channelId}>`, inline: true },
        { name: '📊 Estado', value: count >= 3 ? '⚠️ Se cerrará automáticamente' : 'Pendiente', inline: true }
      )
      .setFooter({ text: '𝐑𝐄𝐀𝐂𝐇𝐒𝐔𝐑𝐕𝐈𝐕𝐀𝐋 𝐓𝐈𝐂𝐊𝐄𝐓𝐒 — Sistema de Tickets' })
      .setTimestamp();
    await interaction.editReply({ embeds: [confirmEmbed], ephemeral: true });
    if (count >= 3) {
      await interaction.channel.send({ embeds: [
        new EmbedBuilder()
          .setColor(0xe74c3c)
          .setTitle('⛔ Ticket cerrado automáticamente')
          .setDescription('Este ticket ha sido cerrado automáticamente después de **3 recordatorios** sin respuesta.')
          .addFields(
            { name: '📊 Recordatorios', value: '3/3', inline: true },
            { name: '👤 Staff responsable', value: `<@${interaction.user.id}>`, inline: true },
            { name: '📋 Acción', value: 'Ticket cerrado por inactividad', inline: true }
          )
          .setFooter({ text: '𝐑𝐄𝐀𝐂𝐇𝐒𝐔𝐑𝐕𝐈𝐕𝐀𝐋 𝐓𝐈𝐂𝐊𝐄𝐓𝐒 — Sistema de Tickets' })
          .setTimestamp()
      ] });
      const pendingTime = Date.now() + 3000;
      await db.run('UPDATE tickets SET pendingClose = ? WHERE channelId = ?', [pendingTime, channelId]);
      await new Promise(resolve => setTimeout(resolve, 3000));
      await closeTicket(channelId, ticket.ticketId, interaction.user, 'Cerrado por recordatorio (3/3)', interaction);
    }
  } catch (error) {
    console.error('Error enviando recordatorio:', error);
    await interaction.editReply({ content: '❌ No se pudo enviar el DM al usuario (tiene los mensajes privados bloqueados).', ephemeral: true });
  }
}

// ==================== NOTAS INTERNAS ====================
async function showNoteModal(interaction, channelId) {
  const modal = new ModalBuilder()
    .setCustomId('note_modal_' + channelId)
    .setTitle('📝 Nota interna')
    .addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('note_content')
          .setLabel('Escribe tu nota')
          .setStyle(TextInputStyle.Paragraph)
          .setMaxLength(2000)
          .setRequired(true)
      )
    );
  return interaction.showModal(modal);
}

async function addInternalNote(interaction, channelId) {
  const note = interaction.fields.getTextInputValue('note_content');
  const ticket = await requireTicket(channelId);
  await addLog(ticket.ticketId, 'nota_interna', interaction.user.id, note);
  const embed = new EmbedBuilder()
    .setColor(0x3498db)
    .setTitle('📝 Nota interna')
    .setDescription(trimText(note, 4000));
  await interaction.channel.send({ embeds: [embed] });
  return interaction.editReply({ content: '✅ Nota interna guardada y publicada en el ticket.', ephemeral: true });
}

// ==================== CONFIRMACIONES DE CIERRE ====================
async function showStaffCloseConfirm(interaction, channelId) {
  const embed = new EmbedBuilder()
    .setColor(0xe74c3c)
    .setTitle('🔒 Confirmar cierre (Staff)')
    .setDescription('¿Seguro que quieres cerrar este ticket? Se generará una transcripción.')
    .setFooter({ text: 'Acción de staff' });
  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('confirm_staff_close_' + channelId).setLabel('✅ Sí, cerrar').setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId('cancel_close_' + channelId).setLabel('❌ Cancelar').setStyle(ButtonStyle.Secondary)
  );
  return interaction.reply({ embeds: [embed], components: [row], ephemeral: true });
}

async function showUserCloseConfirm(interaction, channelId) {
  const embed = new EmbedBuilder()
    .setColor(0xe74c3c)
    .setTitle('🔒 Confirmar cierre')
    .setDescription('¿Seguro que quieres cerrar tu ticket? Se generará una transcripción.')
    .setFooter({ text: 'El ticket se cerrará y no podrás volver a abrirlo' });
  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('confirm_user_close_' + channelId).setLabel('✅ Sí, cerrar').setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId('cancel_close_' + channelId).setLabel('❌ Cancelar').setStyle(ButtonStyle.Secondary)
  );
  return interaction.reply({ embeds: [embed], components: [row], ephemeral: true });
}

// ==================== FUNCIÓN DE CIERRE ====================
async function closeTicket(channelId, ticketId, user, reason, interaction) {
  const ticket = await requireTicket(channelId);
  const channel = await client.channels.fetch(channelId).catch(() => null);
  const channelName = channel?.name || 'ticket-' + channelId;
  
  let messages = [];
  let file = null;
  
  try {
    const token = client.token;
    messages = await getFullChannelMessages(channelId, token);
    const transcriptHTML = buildTranscriptHTML(ticketId, channelId, channelName, messages, channel?.guild);
    await db.run('UPDATE tickets SET transcript = ? WHERE channelId = ?', [transcriptHTML, channelId]);
    file = new AttachmentBuilder(Buffer.from(transcriptHTML, 'utf-8'), { 
      name: `transcript-${ticketId}.html` 
    });
    console.log(`📄 Transcripción HTML generada para ${ticketId} (${messages.length} mensajes)`);
  } catch (e) {
    console.log('Error generando transcripción HTML:', e.message);
  }

  await db.run('UPDATE tickets SET pendingClose = NULL WHERE channelId = ?', [channelId]);
  await db.run("UPDATE tickets SET status = 'closed', closedAt = CURRENT_TIMESTAMP, closedBy = ?, closeReason = ? WHERE channelId = ?",
    [user.id, reason, channelId]);
  await addLog(ticketId, 'cerrado', user.id, reason);

  if (!channel) {
    const openTickets = await getActualOpenTickets(ticket.userId, interaction?.guild);
    if (interaction) {
      await interaction.editReply({ 
        content: `⚠️ El canal del ticket ya no existe. Se ha cerrado en la base de datos.\n📊 **Tickets abiertos restantes:** ${openTickets} de 3`,
        ephemeral: true 
      }).catch(() => {});
    }
    return;
  }

  const participants = new Set([user.id, ticket.userId].filter(Boolean));
  for (const message of messages) {
    if (message.author?.id && !message.author.bot) participants.add(message.author.id);
  }

  const openTickets = await getActualOpenTickets(ticket.userId, channel.guild);

  const closeEmbed = new EmbedBuilder()
    .setColor(0xe74c3c)
    .setTitle('🔒 Ticket cerrado')
    .setDescription(`El ticket **${channelName}** fue cerrado.`)
    .addFields(
      { name: '📋 Nombre del ticket', value: channelName },
      { name: '👥 Personas incluidas', value: Array.from(participants).map((id) => `<@${id}>`).join(', ') || 'N/A' },
      { name: '📂 Categoría', value: ticket.category || 'unknown', inline: true },
      { name: '👤 Cerrado por', value: `<@${user.id}>`, inline: true },
      { name: '📄 Transcripción', value: file ? '✅ HTML Generada' : '❌ No generada', inline: true },
      { name: '📊 Tickets abiertos restantes', value: `${openTickets} de 3`, inline: true },
      { name: '📝 Razón', value: reason, inline: false }
    )
    .setFooter({ text: `Ticket ID: ${ticketId}` });

  if (config.logChannelId && !config.logChannelId.startsWith('PON_AQUI')) {
    const logChannel = await client.channels.fetch(config.logChannelId).catch(() => null);
    if (logChannel) {
      const logPayload = { embeds: [closeEmbed] };
      if (file) logPayload.files = [file];
      await logChannel.send(logPayload).catch((e) => console.error(e.message));
    }
  }

  if (channel) {
    try {
      const finalPayload = { 
        content: `🔒 **Ticket cerrado por <@${user.id}>**\n📄 Transcripción HTML generada (${messages.length} mensajes).\n📊 **Tickets abiertos restantes:** ${openTickets} de 3\n📝 **Razón:** ${reason}` 
      };
      if (file) finalPayload.files = [file];
      await channel.send(finalPayload).catch(() => {});
    } catch (e) {
      console.log('Error enviando mensaje final:', e.message);
    }
    
    setTimeout(() => {
      channel.delete().catch((e) => {
        console.log('No se pudo borrar el canal:', e.message);
      });
    }, 5000);
  }

  try {
    const targetUser = await client.users.fetch(ticket.userId);
    const dmEmbed = new EmbedBuilder()
      .setColor(0xe74c3c)
      .setTitle('🔒 Tu ticket ha sido cerrado')
      .setDescription(`El ticket **${channelName}** ha sido cerrado.`)
      .addFields(
        { name: '📂 Categoría', value: ticket.category || 'unknown', inline: true },
        { name: '👤 Cerrado por', value: `<@${user.id}>`, inline: true },
        { name: '📊 Tickets abiertos restantes', value: `${openTickets} de 3`, inline: true },
        { name: '📝 Razón', value: reason, inline: false }
      )
      .setFooter({ text: `Ticket ID: ${ticketId}` })
      .setTimestamp();
    await targetUser.send({ embeds: [dmEmbed] }).catch(() => {});
  } catch (e) {
    console.log('No se pudo enviar DM al usuario:', e.message);
  }

  if (interaction && !interaction.replied && !interaction.deferred) {
    await interaction.reply({ 
      content: `✅ Ticket cerrado correctamente. Quedan **${openTickets}** tickets abiertos.`,
      ephemeral: true
    }).catch(() => {});
  } else if (interaction) {
    await interaction.editReply({ 
      content: `✅ Ticket cerrado correctamente. Quedan **${openTickets}** tickets abiertos.`,
      ephemeral: true
    }).catch(() => {});
  }
}

// ==================== ARRANQUE ====================
client.login(config.token).catch((err) => {
  console.error('❌ No se pudo iniciar sesión. Revisa que el token en config.json sea correcto y esté vigente.');
  console.error(err.message);
  process.exit(1);
});
