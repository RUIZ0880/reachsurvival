const DISCORD_API = "https://discord.com/api/v10";

const InteractionType = { PING: 1, COMMAND: 2, COMPONENT: 3, MODAL: 5 };
const ResponseType = { PONG: 1, MESSAGE: 4, DEFER: 5, UPDATE: 7, MODAL: 9 };
const ComponentType = { ROW: 1, BUTTON: 2, SELECT: 3, TEXT: 4 };
const ButtonStyle = { PRIMARY: 1, SECONDARY: 2, SUCCESS: 3, DANGER: 4 };
const TextStyle = { SHORT: 1, PARAGRAPH: 2 };
const EPHEMERAL = 64;
const ADMINISTRATOR = 1n << 3n;
const PERMS = {
  VIEW_CHANNEL: 1n << 10n,
  SEND_MESSAGES: 1n << 11n,
  MANAGE_MESSAGES: 1n << 13n,
  ATTACH_FILES: 1n << 15n,
  READ_MESSAGE_HISTORY: 1n << 16n
};

const DEFAULT_STAFF_ROLES = [
  "1510221162742026281",
  "1510221348675391490",
  "1510221532608073799",
  "1510222439618052226",
  "1510224986760024145",
  "1510220501967044719",
  "1510359867662143762"
];

const CATEGORIES = {
  apelacion: {
    roles: [],
    description: "Apelación",
    emoji: "📝",
    menuDescription: "Apela una sanción o baneo",
    categoryId: "1519251872571985951"
  },
  donacion: {
    roles: [],
    description: "Donación",
    emoji: "💎",
    menuDescription: "Donaciones, rangos VIP o items",
    categoryId: "1551350473897017435"
  },
  streamer: {
    roles: [],
    description: "Streamer",
    emoji: "🎥",
    menuDescription: "Solicita el rol de streamer del servidor",
    categoryId: "1551350830999797890"
  },
  reporte_staff: {
    roles: [],
    description: "Reporte STAFF",
    emoji: "🚨",
    menuDescription: "Reporta abuso de poder o mal comportamiento de staff",
    categoryId: "1551305527122853898"
  },
  postulacion_staff: {
    roles: [],
    description: "Postulación STAFF",
    emoji: "👑",
    menuDescription: "Postúlate para unirte al equipo de staff",
    categoryId: "1551351079332094094"
  },
  reporte: {
    roles: [],
    description: "Reporte Jugador",
    emoji: "🚩",
    menuDescription: "Reporta a un jugador por romper las normas",
    categoryId: "1551305667258876014"
  },
  soporte: {
    roles: [],
    description: "Soporte",
    emoji: "🛠️",
    menuDescription: "Ayuda técnica, dudas o problemas en el servidor",
    categoryId: "1551297292068327564"
  },
  otros: {
    roles: [],
    description: "Otros",
    emoji: "📦",
    menuDescription: "Cualquier otra consulta que no encaje arriba",
    categoryId: "1510223819871354910"
  }
};

const DEFAULT_QUESTIONS = [
  { id: "q1", label: "Describe tu consulta con el mayor detalle posible", style: TextStyle.PARAGRAPH }
];

const QUESTIONS = {
  apelacion: [
    { id: "q1", label: "¿Cuál es tu nombre de usuario dentro del servidor?", style: TextStyle.SHORT },
    { id: "q2", label: "¿Por qué fuiste sancionado/a?", style: TextStyle.PARAGRAPH },
    { id: "q3", label: "¿Por qué deberíamos levantar tu sanción?", style: TextStyle.PARAGRAPH }
  ],
  donacion: [
    { id: "q1", label: "¿Qué producto o paquete deseas donar/comprar?", style: TextStyle.SHORT },
    { id: "q2", label: "¿Tienes comprobante o ID de la transacción?", style: TextStyle.PARAGRAPH }
  ],
  streamer: [
    { id: "q1", label: "Enlace a tu canal de streaming", style: TextStyle.SHORT },
    { id: "q2", label: "¿Cuántos seguidores o suscriptores tienes?", style: TextStyle.SHORT },
    { id: "q3", label: "¿Por qué quieres el rol de streamer del servidor?", style: TextStyle.PARAGRAPH }
  ],
  reporte_staff: [
    { id: "q1", label: "Staff reportado (nombre y/o ID)", style: TextStyle.SHORT },
    { id: "q2", label: "Motivo del reporte hacia el staff", style: TextStyle.SHORT },
    { id: "q3", label: "Describe detalladamente lo sucedido", style: TextStyle.PARAGRAPH },
    { id: "q4", label: "¿Tienes evidencia audiovisual? (Enlace)", style: TextStyle.PARAGRAPH }
  ],
  postulacion_staff: [
    { id: "q1", label: "¿Qué cargo de staff te gustaría ocupar?", style: TextStyle.SHORT },
    { id: "q2", label: "¿Cuántos años tienes y cuánto tiempo disponible tienes al día?", style: TextStyle.SHORT },
    { id: "q3", label: "¿Por qué quieres ser parte del equipo de staff?", style: TextStyle.PARAGRAPH },
    { id: "q4", label: "¿Tienes experiencia previa como staff? Cuéntanos", style: TextStyle.PARAGRAPH }
  ],
  reporte: [
    { id: "q1", label: "Nombre y ID del jugador reportado", style: TextStyle.SHORT },
    { id: "q2", label: "Motivo del reporte", style: TextStyle.SHORT },
    { id: "q3", label: "Describe detalladamente lo sucedido", style: TextStyle.PARAGRAPH },
    { id: "q4", label: "¿Tienes evidencia? (clip o capturas)", style: TextStyle.PARAGRAPH }
  ],
  soporte: [
    { id: "q1", label: "Describe tu problema o consulta con detalle", style: TextStyle.PARAGRAPH },
    { id: "q2", label: "¿Qué has intentado para resolverlo?", style: TextStyle.PARAGRAPH }
  ],
  otros: [
    { id: "q1", label: "Describe tu consulta con el mayor detalle posible", style: TextStyle.PARAGRAPH }
  ]
};

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);

    if (request.method === "GET" && url.pathname === "/health") {
      return Response.json({ ok: true, service: "𝐑𝐄𝐀𝐂𝐇𝐒𝐔𝐑𝐕𝐈𝐕𝐀𝐋 𝐓𝐈𝐂𝐊𝐄𝐓𝐒 Ticket Bot Worker", hasDatabase: Boolean(env.DB) });
    }

    if (request.method !== "POST") {
      return new Response("𝐑𝐄𝐀𝐂𝐇𝐒𝐔𝐑𝐕𝐈𝐕𝐀𝐋 𝐓𝐈𝐂𝐊𝐄𝐓𝐒 Ticket Bot Worker", { headers: { "Content-Type": "text/plain; charset=UTF-8" } });
    }

    const signature = request.headers.get("X-Signature-Ed25519");
    const timestamp = request.headers.get("X-Signature-Timestamp");
    const body = await request.text();

    if (!(await verifyDiscordRequest(body, signature, timestamp, env.DISCORD_PUBLIC_KEY))) {
      return new Response("Bad request signature.", { status: 401 });
    }

    let interaction;
    try {
      interaction = JSON.parse(body);
    } catch {
      return new Response("Invalid JSON.", { status: 400 });
    }

    try {
      return await handleInteraction(interaction, env, ctx);
    } catch (error) {
      console.error(JSON.stringify({ message: "Unhandled interaction error", error: getErrorMessage(error) }));
      return reply("❌ Ocurrió un error procesando la interacción.", true);
    }
  }
};

async function handleInteraction(interaction, env, ctx) {
  if (interaction.type === InteractionType.PING) {
    return json({ type: ResponseType.PONG });
  }

  if (interaction.type === InteractionType.COMMAND) {
    return handleCommand(interaction, env, ctx);
  }

  if (interaction.type === InteractionType.COMPONENT) {
    return handleComponent(interaction, env, ctx);
  }

  if (interaction.type === InteractionType.MODAL) {
    return handleModal(interaction, env, ctx);
  }

  return reply("❌ Interacción no soportada.", true);
}

function handleCommand(interaction, env, ctx) {
  if (interaction.data?.name !== "ticketpanel") {
    return reply("❌ Comando no reconocido.", true);
  }

  if (!isStaff(interaction, env)) {
    return reply("❌ Solo el staff puede crear el panel.", true);
  }

  return defer(ctx, interaction, async () => {
    const channelId = interaction.channel_id || getConfig(env).panelChannelId;
    if (!channelId) throw new Error("No encontré el canal donde publicar el panel.");
    await sendPanel(env, channelId);
    await editOriginal(interaction, { content: "✅ Panel de tickets creado en <#" + channelId + ">.", embeds: [], components: [] });
  });
}

function handleComponent(interaction, env, ctx) {
  const customId = interaction.data?.custom_id || "";

  if (customId === "ticket_menu") {
    return ticketModal(interaction.data?.values?.[0]);
  }

  const parsed = parseCustomId(customId);
  const action = parsed.action;
  const channelId = parsed.channelId;
  const staffOnly = ["claim", "unclaim", "transfer", "priority", "transcript", "note", "remind", "close", "confirm_close"];

  if (staffOnly.includes(action) && !isStaff(interaction, env)) {
    return reply("❌ Solo el staff puede usar esta acción.", true);
  }

  if (action === "transfer") return transferModal(channelId);
  if (action === "note") return noteModal(channelId);
  if (action === "close") return closeConfirm(channelId);

  if (action === "cancel_close") {
    return json({ type: ResponseType.UPDATE, data: { content: "❌ Cierre cancelado.", embeds: [], components: [] } });
  }

  if (action === "claim") return defer(ctx, interaction, async () => claimTicket(interaction, env, channelId));
  if (action === "unclaim") return defer(ctx, interaction, async () => unclaimTicket(interaction, env, channelId));
  if (action === "priority") return defer(ctx, interaction, async () => cyclePriority(interaction, env, channelId));
  if (action === "transcript") return defer(ctx, interaction, async () => sendTranscript(interaction, env, channelId));
  if (action === "remind") return defer(ctx, interaction, async () => staffReminder(interaction, env, channelId));
  if (action === "user_remind") return defer(ctx, interaction, async () => userReminder(interaction, env, channelId));
  if (action === "accept_transfer" || action === "reject_transfer") return defer(ctx, interaction, async () => transferAnswer(interaction, env, action, channelId));

  if (action === "confirm_close") {
    return defer(ctx, interaction, async () => {
      const ticket = await requireTicket(env, channelId);
      await closeTicket(env, channelId, ticket.ticketId, getUser(interaction), "Cerrado por staff", interaction);
      await editOriginal(interaction, { content: "✅ Ticket cerrado correctamente.", embeds: [], components: [] });
    });
  }

  return reply("❌ Acción no reconocida.", true);
}

function handleModal(interaction, env, ctx) {
  const customId = interaction.data?.custom_id || "";

  if (customId.startsWith("ticket_create_")) {
    return defer(ctx, interaction, async () => createTicket(interaction, env));
  }

  if (customId.startsWith("transfer_modal_")) {
    if (!isStaff(interaction, env)) return reply("❌ Solo el staff puede transferir tickets.", true);
    return defer(ctx, interaction, async () => transferTicket(interaction, env));
  }

  if (customId.startsWith("note_modal_")) {
    if (!isStaff(interaction, env)) return reply("❌ Solo el staff puede crear notas internas.", true);
    return defer(ctx, interaction, async () => addInternalNote(interaction, env));
  }

  return reply("❌ Formulario no reconocido.", true);
}

async function createTicket(interaction, env) {
  requireToken(env);
  requireDb(env);

  const config = getConfig(env);
  const categoryKey = interaction.data.custom_id.replace("ticket_create_", "");
  const category = CATEGORIES[categoryKey] || { roles: [], description: "General", emoji: "🎫" };
  const user = getUser(interaction);
  const guildId = interaction.guild_id || config.guildId;

  if (!guildId) throw new Error("Los tickets solo pueden abrirse dentro del servidor.");

  const openTicket = await env.DB.prepare("SELECT ticketId, channelId FROM tickets WHERE userId = ? AND status = 'open' LIMIT 1").bind(user.id).first();
  if (openTicket) {
    await editOriginal(interaction, { content: "⚠️ Ya tienes un ticket abierto: <#" + openTicket.channelId + ">.", components: [] });
    return;
  }

  const answers = questionsFor(categoryKey).map((question) => {
    const answer = modalValue(interaction, question.id) || "Sin respuesta";
    return "**" + question.label + ":**\n" + answer;
  }).join("\n\n");

  const channel = await createTicketChannel(env, guildId, user, config, category.categoryId);
  const ticketId = makeTicketId();

  await env.DB.prepare("INSERT INTO tickets (ticketId, userId, channelId, category, answers) VALUES (?, ?, ?, ?, ?)").bind(ticketId, user.id, channel.id, categoryKey, answers).run();
  await addLog(env, ticketId, "creado", user.id, categoryKey);
  await createMessage(env, channel.id, welcomePayload(user, category, answers, channel.id));
  await editOriginal(interaction, { content: "✅ ¡Ticket creado! Ve a <#" + channel.id + "> para continuar.", components: [] });
}

async function claimTicket(interaction, env, channelId) {
  requireDb(env);
  const ticket = await requireTicket(env, channelId);
  const user = getUser(interaction);
  await env.DB.prepare("UPDATE tickets SET claimedBy = ? WHERE channelId = ?").bind(user.id, channelId).run();
  await addLog(env, ticket.ticketId, "reclamado", user.id);
  await editOriginal(interaction, { embeds: [makeEmbed(0x2ecc71, "📌 Ticket reclamado", "El ticket fue reclamado por **" + userTag(user) + "**.", [{ name: "Staff", value: "<@" + user.id + ">", inline: true }])], components: [] });
}

async function unclaimTicket(interaction, env, channelId) {
  requireDb(env);
  const ticket = await requireTicket(env, channelId);
  const user = getUser(interaction);
  await env.DB.prepare("UPDATE tickets SET claimedBy = NULL WHERE channelId = ?").bind(channelId).run();
  await addLog(env, ticket.ticketId, "desreclamado", user.id);
  await editOriginal(interaction, { embeds: [makeEmbed(0xf1c40f, "⏪ Ticket desreclamado", "El ticket fue desreclamado por **" + userTag(user) + "**.", [{ name: "Staff", value: "<@" + user.id + ">", inline: true }])], components: [] });
}

async function cyclePriority(interaction, env, channelId) {
  requireDb(env);
  const ticket = await requireTicket(env, channelId);
  const user = getUser(interaction);
  const priorities = ["normal", "alta", "urgente"];
  const current = priorities.indexOf(ticket.priority || "normal");
  const next = priorities[(current + 1) % priorities.length];
  await env.DB.prepare("UPDATE tickets SET priority = ? WHERE channelId = ?").bind(next, channelId).run();
  await addLog(env, ticket.ticketId, "prioridad_cambiada", user.id, "Nueva: " + next);
  await editOriginal(interaction, { embeds: [makeEmbed(0x2EC4C4, "⭐ Prioridad actualizada", "La prioridad ahora es **" + next.toUpperCase() + "**.", [{ name: "Staff", value: "<@" + user.id + ">", inline: true }])], components: [] });
}

async function sendTranscript(interaction, env, channelId) {
  requireToken(env);
  requireDb(env);
  const ticket = await requireTicket(env, channelId);
  const messages = await fetchMessages(env, channelId);
  const channelName = interaction.channel?.name || "ticket-" + channelId;
  const transcript = buildTranscript(ticket.ticketId, channelId, channelName, messages);
  await env.DB.prepare("UPDATE tickets SET transcript = ? WHERE channelId = ?").bind(transcript, channelId).run();
  await editOriginalWithFile(interaction, { content: "✅ Transcripción generada para **" + ticket.ticketId + "**.", components: [] }, "transcript-" + ticket.ticketId + ".txt", transcript);
}

async function staffReminder(interaction, env, channelId) {
  requireToken(env);
  requireDb(env);
  const ticket = await requireTicket(env, channelId);
  const user = getUser(interaction);
  const count = (ticket.reminderCount || 0) + 1;
  let dmSent = true;
  await env.DB.prepare("UPDATE tickets SET reminderCount = ? WHERE channelId = ?").bind(count, channelId).run();
  try {
    await sendDm(env, ticket.userId, { content: "🔔 **Recordatorio del staff sobre tu ticket:** <#" + channelId + ">\nPor favor, responde para continuar." });
  } catch (error) {
    dmSent = false;
    console.error(JSON.stringify({ message: "No se pudo enviar DM", error: getErrorMessage(error) }));
  }
  await addLog(env, ticket.ticketId, "recordatorio_enviado", user.id, "Count: " + count);
  await editOriginal(interaction, { embeds: [makeEmbed(0xe67e22, "🔔 Recordatorio enviado", (dmSent ? "Se envió DM al usuario." : "No se pudo enviar DM al usuario.") + " (" + count + "/3)")], components: [] });
  if (count >= 3) {
    await closeTicket(env, channelId, ticket.ticketId, user, "Auto-cierre por inactividad", interaction);
  }
}

async function userReminder(interaction, env, channelId) {
  requireToken(env);
  requireDb(env);
  const config = getConfig(env);
  const ticket = await requireTicket(env, channelId);
  const user = getUser(interaction);
  const count = (ticket.userReminderCount || 0) + 1;
  if (count > 3) {
    await editOriginal(interaction, { content: "❌ Límite de 3 recordatorios alcanzado.", components: [] });
    return;
  }
  await env.DB.prepare("UPDATE tickets SET userReminderCount = ? WHERE channelId = ?").bind(count, channelId).run();
  await addLog(env, ticket.ticketId, "recordatorio_usuario", user.id, "Count: " + count);
  const staffMentions = config.staffRoles.map((id) => "<@&" + id + ">").join(" ");
  await createMessage(env, channelId, { content: "🔔 **<@" + user.id + "> solicita atención!** (" + count + "/3)\n" + staffMentions, allowed_mentions: { parse: [], users: [user.id], roles: config.staffRoles } });
  await editOriginal(interaction, { embeds: [makeEmbed(0xe67e22, "⏰ Recordatorio solicitado", "Has solicitado atención para tu ticket. (" + count + "/3)")], components: [] });
}

async function transferTicket(interaction, env) {
  requireToken(env);
  const config = getConfig(env);
  const channelId = interaction.data.custom_id.replace("transfer_modal_", "");
  const targetId = cleanId(modalValue(interaction, "target_user"));
  const user = getUser(interaction);
  if (!targetId) throw new Error("Debes escribir el ID numérico del staff.");
  const member = await discord(env, "/guilds/" + (interaction.guild_id || config.guildId) + "/members/" + targetId).catch(() => null);
  if (member && member.roles && !member.roles.some((id) => config.staffRoles.includes(id))) throw new Error("Ese usuario no tiene un rol de staff configurado.");
  const dm = await createDm(env, targetId);
  await createMessage(env, dm.id, { embeds: [makeEmbed(0xe67e22, "🔄 Solicitud de transferencia", "<@" + user.id + "> quiere transferirte el ticket <#" + channelId + ">.")], components: [{ type: ComponentType.ROW, components: [button("✅ Aceptar", ButtonStyle.SUCCESS, "accept_transfer_" + channelId), button("❌ Rechazar", ButtonStyle.DANGER, "reject_transfer_" + channelId)] }] });
  await editOriginal(interaction, { content: "✅ Solicitud enviada a <@" + targetId + ">.", components: [] });
}

async function transferAnswer(interaction, env, action, channelId) {
  requireToken(env);
  requireDb(env);
  const ticket = await requireTicket(env, channelId);
  const user = getUser(interaction);
  const accepted = action === "accept_transfer";
  if (accepted) {
    await env.DB.prepare("UPDATE tickets SET claimedBy = ? WHERE channelId = ?").bind(user.id, channelId).run();
    await addLog(env, ticket.ticketId, "transferencia_aceptada", user.id);
  } else {
    await addLog(env, ticket.ticketId, "transferencia_rechazada", user.id);
  }
  await createMessage(env, channelId, { embeds: [makeEmbed(accepted ? 0x2ecc71 : 0xe74c3c, accepted ? "✅ Transferencia aceptada" : "❌ Transferencia rechazada", "**" + userTag(user) + "** " + (accepted ? "aceptó" : "rechazó") + " la transferencia.")] });
  await editOriginal(interaction, { content: accepted ? "✅ Has aceptado la transferencia." : "❌ Has rechazado la transferencia.", components: [] });
}

async function addInternalNote(interaction, env) {
  requireToken(env);
  requireDb(env);
  const channelId = interaction.data.custom_id.replace("note_modal_", "");
  const note = modalValue(interaction, "note_content");
  const ticket = await requireTicket(env, channelId);
  const user = getUser(interaction);
  await addLog(env, ticket.ticketId, "nota_interna", user.id, note);
  await createMessage(env, channelId, { embeds: [makeEmbed(0x3498db, "📝 Nota interna", trim(note, 4000), [{ name: "Staff", value: "<@" + user.id + ">", inline: true }])] });
  await editOriginal(interaction, { content: "✅ Nota interna guardada y publicada en el ticket.", components: [] });
}

async function closeTicket(env, channelId, ticketId, user, reason, interaction) {
  requireToken(env);
  requireDb(env);
  const config = getConfig(env);
  const ticket = await requireTicket(env, channelId);
  const messages = await fetchMessages(env, channelId).catch(() => []);
  const channel = await discord(env, "/channels/" + channelId).catch(() => null);
  const channelName = channel?.name || interaction?.channel?.name || "ticket-" + channelId;
  const transcript = buildTranscript(ticketId, channelId, channelName, messages);
  const participants = new Set([user.id, ticket.userId].filter(Boolean));
  for (const message of messages) {
    if (message.author?.id && !message.author.bot) participants.add(message.author.id);
  }
  await env.DB.prepare("UPDATE tickets SET status = 'closed', closedAt = CURRENT_TIMESTAMP, transcript = ?, closedBy = ?, closeReason = ? WHERE channelId = ?").bind(transcript, user.id, reason, channelId).run();
  await addLog(env, ticketId, "cerrado", user.id, reason);
  const closeEmbed = makeEmbed(0xe74c3c, "🔒 Ticket cerrado", "El ticket **" + channelName + "** fue cerrado.", [
    { name: "📋 Nombre del ticket", value: channelName, inline: false },
    { name: "👥 Personas incluidas", value: Array.from(participants).map((id) => "<@" + id + ">").join(", "), inline: false },
    { name: "📂 Categoría", value: ticket.category || "unknown", inline: true },
    { name: "👤 Staff que cerró", value: "<@" + user.id + ">", inline: true },
    { name: "📄 Transcripción", value: "✅ Generada", inline: true }
  ]);
  closeEmbed.footer = { text: "Ticket ID: " + ticketId + " | Razón: " + reason };
  if (config.logChannelId) await createMessageWithFile(env, config.logChannelId, { embeds: [closeEmbed] }, "transcript-" + ticketId + ".txt", transcript).catch((error) => console.error(getErrorMessage(error)));
  await createMessageWithFile(env, channelId, { content: "🔒 **Ticket cerrado por <@" + user.id + ">**\n📄 Transcripción generada.", allowed_mentions: { parse: [], users: [user.id] } }, "transcript-" + ticketId + ".txt", transcript).catch((error) => console.error(getErrorMessage(error)));
  await discord(env, "/channels/" + channelId, { method: "DELETE" }).catch((error) => console.error(getErrorMessage(error)));
}

async function sendPanel(env, channelId) {
  requireToken(env);
  await createMessage(env, channelId, panelPayload());
}

function categoryListText() {
  return Object.values(CATEGORIES).map((c) => c.emoji + " **" + c.description + "** — " + c.menuDescription).join("\n");
}

function panelPayload() {
  const embed = makeEmbed(0x2EC4C4, "🎫 𝐑𝐄𝐀𝐂𝐇𝐒𝐔𝐑𝐕𝐈𝐕𝐀𝐋 𝐓𝐈𝐂𝐊𝐄𝐓𝐒 — SISTEMA DE TICKETS", "> *¡Bienvenido al sistema de atención al jugador de 𝐑𝐄𝐀𝐂𝐇𝐒𝐔𝐑𝐕𝐈𝐕𝐀𝐋 𝐓𝐈𝐂𝐊𝐄𝐓𝐒!*\n\n📌 **¿Cómo funciona?**\n• Selecciona una categoría del menú desplegable\n• Responde las preguntas del formulario\n• Nuestro equipo te atenderá lo antes posible\n\n📂 **Categorías disponibles:**\n\n" + categoryListText());
  // ⚠️ Falta el link CDN del logo de ReachSurvival Tickets — descomenta y pega el link cuando lo tengas
  // embed.image = { url: "PON_AQUI_EL_LINK_DEL_LOGO" };
  return {
    embeds: [embed],
    components: [{ type: ComponentType.ROW, components: [{ type: ComponentType.SELECT, custom_id: "ticket_menu", placeholder: "🔽 Selecciona una categoría...", options: Object.entries(CATEGORIES).map(([key, c]) => ({ label: c.emoji + " " + c.description, description: c.menuDescription.slice(0, 100), value: key })) }] }]
  };
}

function ticketModal(categoryKey) {
  const category = CATEGORIES[categoryKey] || { description: "General" };
  return json({ type: ResponseType.MODAL, data: { custom_id: "ticket_create_" + categoryKey, title: ("📋 " + category.description).slice(0, 45), components: questionsFor(categoryKey).slice(0, 5).map((question) => ({ type: ComponentType.ROW, components: [{ type: ComponentType.TEXT, custom_id: question.id, label: question.label.slice(0, 45), style: question.style, min_length: 11, max_length: question.style === TextStyle.PARAGRAPH ? 2000 : 100, required: true }] })) } });
}

function transferModal(channelId) {
  return json({ type: ResponseType.MODAL, data: { custom_id: "transfer_modal_" + channelId, title: "🔄 Transferir ticket", components: [{ type: ComponentType.ROW, components: [{ type: ComponentType.TEXT, custom_id: "target_user", label: "ID del staff", style: TextStyle.SHORT, placeholder: "Ej: 123456789012345678", min_length: 15, max_length: 25, required: true }] }] } });
}

function noteModal(channelId) {
  return json({ type: ResponseType.MODAL, data: { custom_id: "note_modal_" + channelId, title: "📝 Nota interna", components: [{ type: ComponentType.ROW, components: [{ type: ComponentType.TEXT, custom_id: "note_content", label: "Escribe tu nota", style: TextStyle.PARAGRAPH, max_length: 2000, required: true }] }] } });
}

function closeConfirm(channelId) {
  return json({ type: ResponseType.MESSAGE, data: { flags: EPHEMERAL, embeds: [makeEmbed(0xe74c3c, "🔒 Confirmar cierre", "¿Seguro que quieres cerrar este ticket? Se generará una transcripción.")], components: [{ type: ComponentType.ROW, components: [button("✅ Sí, cerrar", ButtonStyle.DANGER, "confirm_close_" + channelId), button("❌ Cancelar", ButtonStyle.SECONDARY, "cancel_close_" + channelId)] }] } });
}

async function createTicketChannel(env, guildId, user, config, categoryId) {
  const userAllow = bits(PERMS.VIEW_CHANNEL, PERMS.SEND_MESSAGES, PERMS.READ_MESSAGE_HISTORY, PERMS.ATTACH_FILES);
  const staffAllow = bits(PERMS.VIEW_CHANNEL, PERMS.SEND_MESSAGES, PERMS.READ_MESSAGE_HISTORY, PERMS.MANAGE_MESSAGES, PERMS.ATTACH_FILES);
  const payload = {
    name: channelName(user),
    type: 0,
    parent_id: categoryId || config.ticketCategoryId || undefined,
    permission_overwrites: [
      { id: guildId, type: 0, deny: bits(PERMS.VIEW_CHANNEL) },
      { id: user.id, type: 1, allow: userAllow }
    ].concat(config.staffRoles.map((id) => ({ id, type: 0, allow: staffAllow })))
  };
  return discord(env, "/guilds/" + guildId + "/channels", { method: "POST", body: stripUndefined(payload) });
}

function welcomePayload(user, category, answers, channelId) {
  const roleMentions = category.roles.map((id) => "<@&" + id + ">").join(" ");
  return {
    content: "<@" + user.id + ">" + (roleMentions ? " " + roleMentions : ""),
    allowed_mentions: { parse: [], users: [user.id], roles: category.roles },
    embeds: [makeEmbed(0xF39C12, category.emoji + " Nuevo ticket — " + category.description, trim("> *¡Gracias por abrir un ticket! Nuestro equipo te atenderá a la brevedad.*\n\n📋 **Respuestas del formulario:**\n" + answers + "\n\n⏳ *Por favor espera la respuesta de un miembro del staff.*", 4000))],
    components: [
      { type: ComponentType.ROW, components: [button("📌 Reclamar", ButtonStyle.PRIMARY, "claim_" + channelId), button("⏪ Desreclamar", ButtonStyle.SECONDARY, "unclaim_" + channelId), button("🔄 Transferir", ButtonStyle.PRIMARY, "transfer_" + channelId), button("⭐ Priorizar", ButtonStyle.DANGER, "priority_" + channelId)] },
      { type: ComponentType.ROW, components: [button("📄 Transcripción", ButtonStyle.SECONDARY, "transcript_" + channelId), button("📝 Nota interna", ButtonStyle.SECONDARY, "note_" + channelId), button("🔔 Recordatorio", ButtonStyle.PRIMARY, "remind_" + channelId), button("🔒 Cerrar", ButtonStyle.DANGER, "close_" + channelId), button("⏰ Pedir atención", ButtonStyle.SECONDARY, "user_remind_" + channelId)] }
    ]
  };
}

async function requireTicket(env, channelId) {
  requireDb(env);
  const ticket = await env.DB.prepare("SELECT * FROM tickets WHERE channelId = ? LIMIT 1").bind(channelId).first();
  if (!ticket) throw new Error("No encontré este ticket en la base de datos.");
  return ticket;
}

async function addLog(env, ticketId, action, userId, details) {
  if (!env.DB) return;
  await env.DB.prepare("INSERT INTO logs (ticketId, action, userId, details) VALUES (?, ?, ?, ?)").bind(ticketId, action, userId, details || "").run().catch((error) => console.error(getErrorMessage(error)));
}

async function fetchMessages(env, channelId) {
  return discord(env, "/channels/" + channelId + "/messages?limit=100");
}

function buildTranscript(ticketId, channelId, channelName, messages) {
  const lines = ["=== Ticket " + ticketId + " Transcripción ===", "Canal: #" + channelName, "Canal ID: " + channelId, "Generado: " + new Date().toLocaleString("es-MX", { timeZone: "America/Mexico_City" }), ""];
  for (const message of messages.slice().reverse()) {
    const date = new Date(message.timestamp).toLocaleString("es-MX", { timeZone: "America/Mexico_City" });
    const author = message.author ? userTag(message.author) : "Desconocido";
    const attachments = message.attachments?.length ? " [Adjuntos: " + message.attachments.map((item) => item.url).join(", ") + "]" : "";
    lines.push("[" + date + "] " + author + ": " + (message.content || "") + attachments);
  }
  return lines.join("\n");
}

async function createMessage(env, channelId, payload) {
  return discord(env, "/channels/" + channelId + "/messages", { method: "POST", body: payload });
}

async function createMessageWithFile(env, channelId, payload, filename, content) {
  return discord(env, "/channels/" + channelId + "/messages", { method: "POST", body: fileForm(payload, filename, content) });
}

async function sendDm(env, userId, payload) {
  const dm = await createDm(env, userId);
  return createMessage(env, dm.id, payload);
}

async function createDm(env, userId) {
  return discord(env, "/users/@me/channels", { method: "POST", body: { recipient_id: userId } });
}

async function discord(env, path, options) {
  requireToken(env);
  const init = options || {};
  const headers = new Headers(init.headers || {});
  const isForm = init.body instanceof FormData;
  headers.set("Authorization", "Bot " + env.DISCORD_TOKEN);
  if (!isForm && init.body !== undefined) headers.set("Content-Type", "application/json; charset=UTF-8");
  const response = await fetch(DISCORD_API + path, { method: init.method || "GET", headers, body: isForm ? init.body : init.body === undefined ? undefined : JSON.stringify(init.body) });
  if (!response.ok) throw new Error("Discord API " + (init.method || "GET") + " " + path + " respondió " + response.status + ": " + (await response.text()).slice(0, 500));
  if (response.status === 204) return null;
  return response.json();
}

async function editOriginal(interaction, payload) {
  return webhook(interaction, "/messages/@original", { method: "PATCH", body: payload });
}

async function editOriginalWithFile(interaction, payload, filename, content) {
  return webhook(interaction, "/messages/@original", { method: "PATCH", body: fileForm(payload, filename, content) });
}

async function webhook(interaction, path, options) {
  const init = options || {};
  const headers = new Headers(init.headers || {});
  const isForm = init.body instanceof FormData;
  if (!isForm && init.body !== undefined) headers.set("Content-Type", "application/json; charset=UTF-8");
  const response = await fetch(DISCORD_API + "/webhooks/" + interaction.application_id + "/" + interaction.token + path, { method: init.method || "GET", headers, body: isForm ? init.body : init.body === undefined ? undefined : JSON.stringify(init.body) });
  if (!response.ok) throw new Error("Discord webhook respondió " + response.status + ": " + (await response.text()).slice(0, 500));
  if (response.status === 204) return null;
  return response.json();
}

function fileForm(payload, filename, content) {
  const form = new FormData();
  form.set("payload_json", JSON.stringify(Object.assign({}, payload, { attachments: [{ id: 0, filename }] })));
  form.set("files[0]", new Blob([content], { type: "text/plain; charset=UTF-8" }), filename);
  return form;
}

async function verifyDiscordRequest(body, signature, timestamp, publicKey) {
  if (!signature || !timestamp || !publicKey) return false;
  try {
    const key = await crypto.subtle.importKey("raw", hexToBytes(publicKey), { name: "Ed25519" }, false, ["verify"]);
    const data = new TextEncoder().encode(timestamp + body);
    return crypto.subtle.verify({ name: "Ed25519" }, key, hexToBytes(signature), data);
  } catch (error) {
    console.error(JSON.stringify({ message: "Signature verification failed", error: getErrorMessage(error) }));
    return false;
  }
}

function defer(ctx, interaction, task) {
  ctx.waitUntil((async () => {
    try {
      await task();
    } catch (error) {
      console.error(JSON.stringify({ message: "Deferred task failed", error: getErrorMessage(error) }));
      await editOriginal(interaction, { content: "❌ Error: " + trim(getErrorMessage(error), 1800), embeds: [], components: [] }).catch((editError) => console.error(getErrorMessage(editError)));
    }
  })());
  return json({ type: ResponseType.DEFER, data: { flags: EPHEMERAL } });
}

function reply(content, ephemeral) {
  return json({ type: ResponseType.MESSAGE, data: { content, flags: ephemeral ? EPHEMERAL : undefined } });
}

function json(payload) {
  return Response.json(payload, { headers: { "Content-Type": "application/json; charset=UTF-8" } });
}

function parseCustomId(customId) {
  const prefixes = ["confirm_close_", "cancel_close_", "accept_transfer_", "reject_transfer_", "user_remind_"];
  const prefix = prefixes.find((item) => customId.startsWith(item));
  if (prefix) return { action: prefix.slice(0, -1), channelId: customId.slice(prefix.length) };
  const index = customId.indexOf("_");
  if (index === -1) return { action: customId, channelId: "" };
  return { action: customId.slice(0, index), channelId: customId.slice(index + 1) };
}

function getConfig(env) {
  const roles = splitIds(env.STAFF_ROLES);
  return { guildId: env.DISCORD_GUILD_ID || "", panelChannelId: env.PANEL_CHANNEL_ID || "", ticketCategoryId: env.TICKET_CATEGORY_ID || "", logChannelId: env.LOG_CHANNEL_ID || "", staffRoles: roles.length ? roles : DEFAULT_STAFF_ROLES, ownerIds: splitIds(env.OWNER_IDS) };
}

function isStaff(interaction, env) {
  const config = getConfig(env);
  const user = getUser(interaction);
  const roles = interaction.member?.roles || [];
  const permissions = BigInt(interaction.member?.permissions || "0");
  return config.ownerIds.includes(user.id) || roles.some((id) => config.staffRoles.includes(id)) || (permissions & ADMINISTRATOR) === ADMINISTRATOR;
}

function questionsFor(categoryKey) {
  return QUESTIONS[categoryKey] || DEFAULT_QUESTIONS;
}

function getUser(interaction) {
  return interaction.member?.user || interaction.user || { id: "unknown", username: "usuario" };
}

function modalValue(interaction, fieldId) {
  for (const row of interaction.data?.components || []) {
    for (const component of row.components || []) {
      if (component.custom_id === fieldId) return String(component.value || "").trim();
    }
  }
  return "";
}

function userTag(user) {
  if (!user) return "Desconocido";
  if (user.discriminator && user.discriminator !== "0") return user.username + "#" + user.discriminator;
  return user.global_name || user.username || user.id || "Desconocido";
}

function channelName(user) {
  const raw = (user.global_name || user.username || user.id || "usuario").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9-]/g, "").slice(0, 30);
  return ("ticket-" + (raw || String(user.id).slice(-6))).slice(0, 90);
}

function makeTicketId() {
  const random = new Uint8Array(3);
  crypto.getRandomValues(random);
  const suffix = Array.from(random).map((byte) => byte.toString(16).padStart(2, "0")).join("").toUpperCase();
  return "EX-" + Date.now().toString(36).toUpperCase() + "-" + suffix;
}

function bits() {
  return Array.from(arguments).reduce((total, bit) => total | bit, 0n).toString();
}

function splitIds(value) {
  return String(value || "").split(",").map((item) => item.trim()).filter(Boolean);
}

function cleanId(value) {
  return String(value || "").replace(/\D/g, "");
}

function stripUndefined(value) {
  return Object.fromEntries(Object.entries(value).filter((entry) => entry[1] !== undefined && entry[1] !== ""));
}

function trim(value, max) {
  const text = String(value || "");
  return text.length > max ? text.slice(0, Math.max(0, max - 15)) + "\n...[recortado]" : text;
}

function button(label, style, customId) {
  return { type: ComponentType.BUTTON, style, label, custom_id: customId };
}

function makeEmbed(color, title, description, fields) {
  return { color, title, description, fields, timestamp: new Date().toISOString() };
}

function hexToBytes(hex) {
  const clean = String(hex || "").trim();
  if (!/^[\da-f]+$/i.test(clean) || clean.length % 2 !== 0) throw new Error("Valor hexadecimal inválido.");
  const bytes = new Uint8Array(clean.length / 2);
  for (let index = 0; index < clean.length; index += 2) bytes[index / 2] = Number.parseInt(clean.slice(index, index + 2), 16);
  return bytes;
}

function requireToken(env) {
  if (!env.DISCORD_TOKEN) throw new Error("Falta configurar el secreto DISCORD_TOKEN en Cloudflare.");
}

function requireDb(env) {
  if (!env.DB) throw new Error("Falta configurar la base D1 con binding DB.");
}

function getErrorMessage(error) {
  return error instanceof Error ? error.message : String(error);
}
