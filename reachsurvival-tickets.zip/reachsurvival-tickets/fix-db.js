const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const dbPath = path.resolve(__dirname, 'tickets.db');
const db = new sqlite3.Database(dbPath);

// Verificar si la columna existe
db.all("PRAGMA table_info(tickets)", (err, rows) => {
  if (err) {
    console.error('Error:', err.message);
    db.close();
    return;
  }
  
  const cols = rows.map(r => r.name);
  if (!cols.includes('pendingClose')) {
    db.run('ALTER TABLE tickets ADD COLUMN pendingClose DATETIME DEFAULT NULL', (err) => {
      if (err) {
        console.error('❌ Error añadiendo columna:', err.message);
      } else {
        console.log('✅ Columna pendingClose añadida correctamente');
      }
      db.close();
    });
  } else {
    console.log('ℹ️ La columna pendingClose ya existe');
    db.close();
  }
});